import { Sprout, ExternalLink, Mail, MapPin, Heart } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { Page } from '@/lib/types';

export function Footer({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { t } = useLanguage();

  const links: { page: Page; key: string }[] = [
    { page: 'weather', key: 'nav_weather' },
    { page: 'calendar', key: 'nav_calendar' },
    { page: 'market', key: 'nav_market' },
    { page: 'schemes', key: 'nav_schemes' },
    { page: 'disease', key: 'nav_disease' },
    { page: 'profit', key: 'nav_profit' },
    { page: 'assistant', key: 'nav_assistant' },
    { page: 'risk', key: 'nav_risk' },
    { page: 'location', key: 'nav_location' },
    { page: 'soil', key: 'nav_soil' },
    { page: 'records', key: 'nav_records' },
    { page: 'marketplace', key: 'nav_marketplace' },
    { page: 'passport', key: 'nav_passport' },
  ];

  const resources: { label: string; url: string }[] = [
    { label: 'J&K Horticulture Planning & Marketing', url: 'https://dhpm.jk.gov.in/' },
    { label: 'Department of Horticulture, J&K', url: 'https://jkhorticulture.in/' },
    { label: 'PM-KISAN Portal', url: 'https://pmkisan.gov.in/' },
    { label: 'eNAM National Market', url: 'https://enam.gov.in/' },
  ];

  return (
    <footer className="bg-stone-900 text-stone-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-14 pb-8">
        <div className="grid md:grid-cols-12 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shadow-md">
                <Sprout className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-white text-lg tracking-tight">{t('app_name')}</span>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed max-w-sm mb-4">
              {t('footer_about_text')}
            </p>
            <div className="flex flex-col gap-2 text-sm text-stone-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-brand-500" />
                Jammu &amp; Kashmir, India
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-brand-500" />
                hello@kisanshield.in
              </div>
            </div>
          </div>

          {/* Quick links */}
          <div className="md:col-span-3">
            <h3 className="font-semibold text-white mb-4 text-sm tracking-wide uppercase">{t('footer_links')}</h3>
            <ul className="space-y-2.5">
              {links.map((l) => (
                <li key={l.page}>
                  <button
                    onClick={() => onNavigate(l.page)}
                    className="text-sm text-stone-400 hover:text-brand-400 transition-colors"
                  >
                    {t(l.key)}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div className="md:col-span-4">
            <h3 className="font-semibold text-white mb-4 text-sm tracking-wide uppercase">Official Resources</h3>
            <ul className="space-y-2.5">
              {resources.map((r) => (
                <li key={r.url}>
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-sm text-stone-400 hover:text-brand-400 transition-colors inline-flex items-center gap-1.5 group"
                  >
                    {r.label}
                    <ExternalLink className="w-3 h-3 opacity-50 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-6 border-t border-stone-800 space-y-3">
          <p className="text-xs text-stone-500 leading-relaxed max-w-3xl">{t('footer_disclaimer')}</p>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <p className="text-xs text-stone-500 flex items-center gap-1.5">
              {t('footer_rights')}
              <Heart className="w-3 h-3 text-clay-500" />
            </p>
            <p className="text-xs text-stone-600">© {new Date().getFullYear()} {t('app_name')}</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
