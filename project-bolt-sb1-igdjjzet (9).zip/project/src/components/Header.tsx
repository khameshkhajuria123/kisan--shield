import { useState } from 'react';
import {
  Globe,
  Menu,
  X,
  Sprout,
  ChevronDown,
  CloudRain,
  CalendarDays,
  TrendingUp,
  Landmark,
  Leaf,
  Calculator,
  LayoutDashboard,
  Check,
  Bot,
  ShieldAlert,
  MapPin,
  Droplets,
  ClipboardList,
  Store,
  QrCode,
} from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { LANGS, Lang } from '@/i18n/translations';
import { Page } from '@/lib/types';

type NavItem = { page: Page; key: string; icon: typeof Globe };

const NAV: NavItem[] = [
  { page: 'home', key: 'nav_home', icon: LayoutDashboard },
  { page: 'weather', key: 'nav_weather', icon: CloudRain },
  { page: 'calendar', key: 'nav_calendar', icon: CalendarDays },
  { page: 'market', key: 'nav_market', icon: TrendingUp },
  { page: 'schemes', key: 'nav_schemes', icon: Landmark },
  { page: 'disease', key: 'nav_disease', icon: Leaf },
  { page: 'profit', key: 'nav_profit', icon: Calculator },
  { page: 'assistant', key: 'nav_assistant', icon: Bot },
  { page: 'risk', key: 'nav_risk', icon: ShieldAlert },
  { page: 'location', key: 'nav_location', icon: MapPin },
  { page: 'soil', key: 'nav_soil', icon: Droplets },
  { page: 'records', key: 'nav_records', icon: ClipboardList },
  { page: 'marketplace', key: 'nav_marketplace', icon: Store },
  { page: 'passport', key: 'nav_passport', icon: QrCode },
];

export function Header({
  current,
  onNavigate,
}: {
  current: Page;
  onNavigate: (p: Page) => void;
}) {
  const { lang, setLang, t, dir } = useLanguage();
  const [langOpen, setLangOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLang = (l: Lang) => {
    setLang(l);
    setLangOpen(false);
  };

  const handleNav = (p: Page) => {
    onNavigate(p);
    setMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-xl border-b border-stone-200/80 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-2.5 shrink-0 group"
          >
            <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shadow-md group-hover:shadow-glow transition-all group-hover:scale-105">
              <Sprout className="w-5 h-5 text-white" />
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-wheat-400 border-2 border-white" />
            </div>
            <div className="text-start leading-tight">
              <div className="font-bold text-stone-800 text-sm sm:text-base tracking-tight">
                {t('app_name')}
              </div>
              <div className="hidden sm:block text-[10px] text-stone-500 font-medium">
                {t('app_tagline')}
              </div>
            </div>
          </button>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-0.5">
            {NAV.map((item) => {
              const active = current === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => handleNav(item.page)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                    active
                      ? 'bg-brand-50 text-brand-700'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/70'
                  }`}
                >
                  <item.icon className={`w-4 h-4 ${active ? 'text-brand-600' : 'text-stone-400'}`} />
                  {t(item.key)}
                </button>
              );
            })}
          </nav>

          {/* Language + mobile toggle */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="relative">
              <button
                onClick={() => setLangOpen((v) => !v)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-stone-700 bg-stone-100/80 hover:bg-stone-200/80 transition-colors border border-stone-200/50"
                aria-label={t('lang_select')}
              >
                <Globe className="w-4 h-4 text-brand-600" />
                <span className="hidden sm:inline">{LANGS.find((l) => l.code === lang)?.native}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${langOpen ? 'rotate-180' : ''}`} />
              </button>
              {langOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setLangOpen(false)} />
                  <div className={`absolute ${dir === 'rtl' ? 'left-0' : 'right-0'} mt-2 w-52 bg-white rounded-2xl shadow-card border border-stone-100 py-1.5 z-50 overflow-hidden`}>
                    <div className="px-3 py-2 text-[10px] font-bold tracking-widest uppercase text-stone-400">
                      {t('lang_select')}
                    </div>
                    {LANGS.map((l) => (
                      <button
                        key={l.code}
                        onClick={() => handleLang(l.code)}
                        className={`w-full text-start px-3 py-2.5 text-sm flex items-center justify-between transition-colors ${
                          lang === l.code
                            ? 'bg-brand-50 text-brand-700 font-semibold'
                            : 'text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span className="text-base">{l.native}</span>
                        </span>
                        {lang === l.code ? (
                          <Check className="w-4 h-4 text-brand-600" />
                        ) : (
                          <span className="text-xs text-stone-400">{l.label}</span>
                        )}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="lg:hidden p-2 rounded-xl text-stone-700 hover:bg-stone-100 transition-colors"
              aria-label="Menu"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {menuOpen && (
          <nav className="lg:hidden pb-4 pt-1 flex flex-col gap-0.5 animate-slide-up">
            {NAV.map((item) => {
              const active = current === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => handleNav(item.page)}
                  className={`flex items-center gap-2.5 text-start px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                    active ? 'bg-brand-50 text-brand-700' : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  <item.icon className={`w-4 h-4 ${active ? 'text-brand-600' : 'text-stone-400'}`} />
                  {t(item.key)}
                </button>
              );
            })}
          </nav>
        )}
      </div>
    </header>
  );
}
