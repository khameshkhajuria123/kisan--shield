import { ReactNode } from 'react';
import { AlertTriangle, Loader2, RefreshCw, Inbox } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

export function Loading() {
  const { t } = useLanguage();
  return (
    <div className="flex items-center justify-center py-20 animate-fade-in">
      <Loader2 className="w-6 h-6 text-brand-600 animate-spin" />
      <span className="ms-3 text-stone-500 font-medium">{t('loading')}</span>
    </div>
  );
}

export function ErrorState({ onRetry }: { onRetry?: () => void }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4 text-center animate-fade-in">
      <div className="w-14 h-14 rounded-2xl bg-amber-100 flex items-center justify-center">
        <AlertTriangle className="w-7 h-7 text-amber-600" />
      </div>
      <p className="text-stone-600 max-w-sm">{t('error_generic')}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft"
        >
          <RefreshCw className="w-4 h-4" />
          {t('retry')}
        </button>
      )}
    </div>
  );
}

export function EmptyState({ message }: { message?: string }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3 text-center animate-fade-in">
      <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center">
        <Inbox className="w-7 h-7 text-stone-400" />
      </div>
      <p className="text-stone-500">{message ?? t('no_data')}</p>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  icon,
}: {
  title: string;
  subtitle: string;
  icon?: ReactNode;
}) {
  return (
    <div className="mb-8 animate-slide-up">
      <div className="flex items-center gap-3 mb-3">
        {icon && (
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-brand-100 to-brand-200 flex items-center justify-center text-brand-700 shrink-0 shadow-sm">
            {icon}
          </div>
        )}
        <h1 className="text-2xl sm:text-3xl font-bold text-stone-800 tracking-tight">{title}</h1>
      </div>
      <p className="text-stone-600 leading-relaxed max-w-3xl text-sm sm:text-base">
        {subtitle}
      </p>
    </div>
  );
}

export function Disclaimer({ text }: { text: string }) {
  return (
    <div className="mt-8 rounded-xl bg-wheat-50 border border-wheat-200 p-4 flex items-start gap-2.5">
      <AlertTriangle className="w-4 h-4 text-wheat-600 shrink-0 mt-0.5" />
      <p className="text-xs text-wheat-800 leading-relaxed">{text}</p>
    </div>
  );
}

export function SectionTitle({
  eyebrow,
  title,
  subtitle,
  center,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <div className={`mb-10 ${center ? 'text-center' : ''}`}>
      {eyebrow && (
        <div className={`text-xs font-bold tracking-widest uppercase text-brand-600 mb-2 ${center ? '' : ''}`}>
          {eyebrow}
        </div>
      )}
      <h2 className="text-2xl sm:text-3xl font-bold text-stone-800 tracking-tight mb-2">{title}</h2>
      {subtitle && <p className={`text-stone-600 ${center ? 'max-w-2xl mx-auto' : ''}`}>{subtitle}</p>}
    </div>
  );
}

export function PageBanner({
  image,
  title,
  subtitle,
  icon,
}: {
  image: string;
  title: string;
  subtitle: string;
  icon?: ReactNode;
}) {
  return (
    <div className="relative overflow-hidden rounded-3xl mb-8 shadow-card">
      <div className="relative h-44 sm:h-56">
        <img src={image} alt={title} className="w-full h-full object-cover" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-br from-brand-950/85 via-brand-900/75 to-stone-900/80" />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full">
            <div className="flex items-center gap-3 mb-2">
              {icon && (
                <div className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur flex items-center justify-center text-white shrink-0 border border-white/20">
                  {icon}
                </div>
              )}
              <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">{title}</h1>
            </div>
            <p className="text-white/75 leading-relaxed max-w-2xl text-sm sm:text-base">
              {subtitle}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="bg-white rounded-2xl border border-stone-100 p-5 shadow-soft">
      <div className="skeleton h-10 w-10 rounded-xl mb-4" />
      <div className="skeleton h-4 w-3/4 rounded mb-2" />
      <div className="skeleton h-3 w-full rounded mb-1" />
      <div className="skeleton h-3 w-5/6 rounded" />
    </div>
  );
}
