import { useMemo, useState } from 'react';
import { Leaf, Upload, Sprout, AlertTriangle, ShieldCheck, FlaskConical, Info, Camera, ImageIcon } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, DiseaseEntry } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer, SectionTitle } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const SEVERITY_STYLE: Record<string, string> = {
  High: 'bg-red-50 text-red-700 border-red-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  Low: 'bg-brand-50 text-brand-700 border-brand-200',
};

export function DiseasePage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState('all');
  const [uploadName, setUploadName] = useState<string | null>(null);
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);

  const { data, loading, error, reload } = useFetch<{ entries: DiseaseEntry[]; crops: string[] }>(async () => {
    const { data, error } = await supabase.from('disease_library').select('*').order('crop, disease_name');
    if (error) throw error;
    const crops = Array.from(new Set(data?.map((r) => r.crop) ?? [])).sort();
    return { entries: data ?? [], crops };
  }, []);

  const filtered = useMemo(() => {
    if (crop === 'all') return data?.entries ?? [];
    return (data?.entries ?? []).filter((e) => e.crop === crop);
  }, [data, crop]);

  const onFile = (file: File | undefined) => {
    if (!file) return;
    setUploadName(file.name);
    const reader = new FileReader();
    reader.onload = () => setUploadPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  if (loading) return <Loading />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.appleTree}
        title={t('disease_title')}
        subtitle={t('disease_sub')}
        icon={<Leaf className="w-5 h-5" />}
      />

      {/* Upload section */}
      <div className="grid lg:grid-cols-3 gap-6 mb-10">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-stone-100 shadow-soft p-6">
          <label className="block border-2 border-dashed border-stone-300 rounded-2xl p-10 text-center cursor-pointer hover:border-brand-400 hover:bg-brand-50/30 transition-all">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => onFile(e.target.files?.[0])}
            />
            {uploadPreview ? (
              <div className="flex flex-col items-center gap-3 animate-fade-in">
                <img src={uploadPreview} alt="upload" className="max-h-56 rounded-xl shadow-md" />
                <p className="text-sm text-stone-600 font-medium">{uploadName}</p>
                <span className="text-xs text-brand-600 font-semibold">{t('disease_upload')}</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-100 to-brand-200 flex items-center justify-center text-brand-600">
                  <Camera className="w-8 h-8" />
                </div>
                <div>
                  <p className="font-bold text-stone-700 text-lg">{t('disease_upload')}</p>
                  <p className="text-xs text-stone-500 mt-1">JPG, PNG — max ~5 MB</p>
                </div>
              </div>
            )}
          </label>

          {uploadPreview && (
            <div className="mt-4 rounded-xl bg-wheat-50 border border-wheat-200 p-4 flex items-start gap-2.5">
              <Info className="w-5 h-5 text-wheat-600 shrink-0 mt-0.5" />
              <p className="text-sm text-wheat-800 leading-relaxed">
                {t('disease_disclaimer')}
              </p>
            </div>
          )}
        </div>

        {/* Side tip card */}
        <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-2xl p-6 text-white relative overflow-hidden">
          <div className="absolute -top-8 -end-8 w-32 h-32 rounded-full bg-white/10" />
          <div className="relative">
            <ImageIcon className="w-8 h-8 mb-4 text-brand-200" />
            <h3 className="font-bold text-lg mb-2">{t('disease_upload')}</h3>
            <p className="text-sm text-white/80 leading-relaxed mb-4">{t('disease_sub')}</p>
            <div className="flex items-center gap-2 text-xs text-brand-200">
              <Info className="w-4 h-4" />
              {t('disease_disclaimer')}
            </div>
          </div>
        </div>
      </div>

      {/* Browse by crop */}
      <SectionTitle eyebrow="Library" title={t('disease_select_crop')} />

      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setCrop('all')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            crop === 'all' ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          {t('calendar_all_crops')}
        </button>
        {data?.crops.map((c) => (
          <button
            key={c}
            onClick={() => setCrop(c)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              crop === c ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid sm:grid-cols-2 gap-5 stagger">
          {filtered.map((d) => (
            <div key={d.id} className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 card-hover">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div>
                  <h3 className="font-bold text-stone-800 text-lg">{d.disease_name}</h3>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-stone-100 text-stone-600 font-medium">{d.crop}</span>
                    {d.type && <span className="text-xs px-2.5 py-1 rounded-full bg-sky-50 text-sky-700 font-medium">{d.type}</span>}
                  </div>
                </div>
                {d.severity && (
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${SEVERITY_STYLE[d.severity] ?? 'bg-stone-100 text-stone-700 border-stone-200'}`}>
                    {d.severity}
                  </span>
                )}
              </div>

              {d.symptoms && (
                <div className="mb-3 rounded-xl bg-amber-50/50 p-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                    {t('disease_symptoms')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{d.symptoms}</p>
                </div>
              )}
              {d.treatment && (
                <div className="mb-3 rounded-xl bg-rose-50/50 p-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <FlaskConical className="w-3.5 h-3.5 text-rose-500" />
                    {t('disease_treatment')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{d.treatment}</p>
                </div>
              )}
              {d.prevention && (
                <div className="rounded-xl bg-brand-50/50 p-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <ShieldCheck className="w-3.5 h-3.5 text-brand-500" />
                    {t('disease_prevention')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{d.prevention}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Disclaimer text={t('disease_disclaimer')} />
    </div>
  );
}
