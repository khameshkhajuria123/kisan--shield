import { useMemo, useState } from 'react';
import { CalendarDays, Sprout, Scissors, Droplets, SprayCan, Flower, Apple, Package, Wheat, Sun, LeafyGreen } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, CropCalendar } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner } from '@/components/ui';
import { PHOTOS, CROP_PHOTO } from '@/lib/photos';

const ICONS: Record<string, typeof Sprout> = {
  Sprout, Scissors, Droplets, SprayCan, Flower, Apple, Package, Wheat, Sun, LeafyGreen,
};

const CROP_EMOJI: Record<string, string> = {
  Apple: '🍎',
  Saffron: '🌺',
  Rice: '🌾',
  Walnut: '🌰',
  Maize: '🌽',
  Tomato: '🍅',
};

const MONTH_COLORS: Record<number, string> = {
  1: 'from-blue-400 to-cyan-500',
  2: 'from-blue-400 to-indigo-500',
  3: 'from-emerald-400 to-teal-500',
  4: 'from-emerald-400 to-green-500',
  5: 'from-lime-400 to-emerald-500',
  6: 'from-amber-400 to-orange-500',
  7: 'from-orange-400 to-red-500',
  8: 'from-orange-400 to-amber-500',
  9: 'from-amber-400 to-yellow-500',
  10: 'from-orange-400 to-red-500',
  11: 'from-stone-400 to-amber-500',
  12: 'from-blue-400 to-slate-500',
};

export function CalendarPage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState('all');

  const { data, loading, error, reload } = useFetch<{ entries: CropCalendar[]; crops: string[] }>(async () => {
    const { data, error } = await supabase.from('crop_calendar').select('*').order('month, crop');
    if (error) throw error;
    const crops = Array.from(new Set(data?.map((r) => r.crop) ?? [])).sort();
    return { entries: data ?? [], crops };
  }, []);

  const filtered = useMemo(() => {
    if (crop === 'all') return data?.entries ?? [];
    return (data?.entries ?? []).filter((e) => e.crop === crop);
  }, [data, crop]);

  const byMonth = useMemo(() => {
    const map = new Map<number, CropCalendar[]>();
    for (let m = 1; m <= 12; m++) map.set(m, []);
    for (const e of filtered) map.get(e.month)?.push(e);
    return map;
  }, [filtered]);

  if (loading) return <Loading />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={crop !== 'all' && CROP_PHOTO[crop] ? CROP_PHOTO[crop] : PHOTOS.saffronField}
        title={t('calendar_title')}
        subtitle={t('calendar_sub')}
        icon={<CalendarDays className="w-5 h-5" />}
      />

      {/* Crop filter */}
      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setCrop('all')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            crop === 'all' ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          {t('calendar_all_crops')}
        </button>
        {data?.crops.map((c) => (
          <button
            key={c}
            onClick={() => setCrop(c)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all inline-flex items-center gap-1.5 ${
              crop === c ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            <span>{CROP_EMOJI[c] ?? '🌱'}</span>
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="space-y-5 stagger">
          {Array.from(byMonth.entries()).map(([month, entries]) => {
            if (entries.length === 0) return null;
            return (
              <div key={month} className="bg-white rounded-2xl border border-stone-100 shadow-soft overflow-hidden">
                <div className={`px-5 py-3.5 bg-gradient-to-r ${MONTH_COLORS[month] ?? 'from-brand-400 to-teal-500'} relative overflow-hidden`}>
                  <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 90% 50%, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                  <h3 className="font-bold text-white relative tracking-tight">{t(`calendar_month_${month}`)}</h3>
                </div>
                <div className="divide-y divide-stone-50">
                  {entries.map((e) => {
                    const Icon = ICONS[e.icon ?? ''] ?? Sprout;
                    return (
                      <div key={e.id} className="flex items-start gap-3.5 p-4 hover:bg-stone-50/50 transition-colors">
                        <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center text-brand-600 shrink-0">
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-stone-800 text-sm">{e.operation}</span>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 font-medium">
                              {CROP_EMOJI[e.crop] ?? '🌱'} {e.crop}
                            </span>
                          </div>
                          {e.detail && <p className="text-sm text-stone-600 mt-1 leading-relaxed">{e.detail}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
