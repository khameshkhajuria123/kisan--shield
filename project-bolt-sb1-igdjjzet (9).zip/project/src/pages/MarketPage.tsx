import { useMemo, useState } from 'react';
import { TrendingUp, IndianRupee, MapPin } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, MarketPrice } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

export function MarketPage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState('all');

  const { data, loading, error, reload } = useFetch<{ rows: MarketPrice[]; crops: string[] }>(async () => {
    const { data, error } = await supabase
      .from('market_prices')
      .select('*')
      .order('price_date', { ascending: false });
    if (error) throw error;
    const crops = Array.from(new Set(data?.map((r) => r.crop) ?? [])).sort();
    return { rows: data ?? [], crops };
  }, []);

  const filtered = useMemo(() => {
    if (crop === 'all') return data?.rows ?? [];
    return (data?.rows ?? []).filter((r) => r.crop === crop);
  }, [data, crop]);

  if (loading) return <Loading />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.appleHarvest}
        title={t('market_title')}
        subtitle={t('market_sub')}
        icon={<TrendingUp className="w-5 h-5" />}
      />

      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setCrop('all')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            crop === 'all' ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          {t('market_all')}
        </button>
        {data?.crops.map((c) => (
          <button
            key={c}
            onClick={() => setCrop(c)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              crop === c ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState />
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden md:block bg-white rounded-2xl border border-stone-100 shadow-soft overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-stone-50/80 text-stone-500 text-xs uppercase tracking-wide">
                <tr>
                  <th className="px-5 py-3.5 text-start font-semibold">{t('market_crop')}</th>
                  <th className="px-5 py-3.5 text-start font-semibold">{t('market_variety')}</th>
                  <th className="px-5 py-3.5 text-start font-semibold">{t('market_grade')}</th>
                  <th className="px-5 py-3.5 text-start font-semibold">{t('market_mandi')}</th>
                  <th className="px-5 py-3.5 text-end font-semibold">{t('market_price')}</th>
                  <th className="px-5 py-3.5 text-start font-semibold">{t('market_date')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-50">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-brand-50/30 transition-colors">
                    <td className="px-5 py-3.5 font-semibold text-stone-800">{r.crop}</td>
                    <td className="px-5 py-3.5 text-stone-600">{r.variety ?? '—'}</td>
                    <td className="px-5 py-3.5">
                      {r.grade && <span className="px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 text-xs font-semibold">{r.grade}</span>}
                    </td>
                    <td className="px-5 py-3.5 text-stone-600">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-stone-400" />
                        {r.mandi}{r.district ? `, ${r.district}` : ''}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-end">
                      <span className="font-bold text-brand-700 text-base flex items-center justify-end gap-0.5">
                        <IndianRupee className="w-4 h-4" />
                        {r.price_per_kg.toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs text-stone-400">/{r.unit}</span>
                    </td>
                    <td className="px-5 py-3.5 text-stone-500 text-xs">{new Date(r.price_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3 stagger">
            {filtered.map((r) => (
              <div key={r.id} className="bg-white rounded-2xl border border-stone-100 shadow-soft p-4 card-hover">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <div className="font-bold text-stone-800">{r.crop}</div>
                    <div className="text-xs text-stone-500 mt-0.5">{r.variety ?? '—'} · {r.grade ?? '—'}</div>
                  </div>
                  <div className="text-end">
                    <div className="font-bold text-brand-700 text-lg flex items-center justify-end gap-0.5">
                      <IndianRupee className="w-3.5 h-3.5" />
                      {r.price_per_kg.toLocaleString('en-IN')}
                    </div>
                    <div className="text-xs text-stone-400">/{r.unit}</div>
                  </div>
                </div>
                <div className="text-xs text-stone-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {r.mandi}{r.district ? `, ${r.district}` : ''} · {new Date(r.price_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      <Disclaimer text={t('market_sub')} />
    </div>
  );
}
