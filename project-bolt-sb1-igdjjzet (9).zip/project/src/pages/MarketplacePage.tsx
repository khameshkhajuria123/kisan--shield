import { useState, useMemo } from 'react';
import { Store, Save, Trash2, Phone, MapPin, Sprout, Plus, Check, Package } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, MarketplaceListing } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS, CROP_PHOTO } from '@/lib/photos';

const CROPS = ['Apple', 'Saffron', 'Rice', 'Walnut', 'Maize', 'Tomato'];
const GRADES = ['A', 'B', 'C'];
const DISTRICTS = ['Srinagar', 'Baramulla', 'Shopian', 'Anantnag', 'Pulwama', 'Kulgam', 'Budgam', 'Kupwara', 'Ganderbal', 'Bandipora', 'Jammu', 'Udhampur', 'Kathua', 'Doda'];

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

export function MarketplacePage() {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [cropFilter, setCropFilter] = useState('all');
  const sessionId = getSessionId();

  const emptyForm = { crop: 'Apple', variety: '', quantity_kg: '', grade: 'A', price_per_kg: '', district: 'Srinagar', contact_name: '', contact_phone: '', notes: '' };
  const [form, setForm] = useState(emptyForm);

  const { data: listings, loading, error, reload } = useFetch<MarketplaceListing[]>(async () => {
    const { data } = await supabase
      .from('marketplace_listings')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });
    return data ?? [];
  }, []);

  const filtered = useMemo(() => {
    if (!listings) return [];
    return cropFilter === 'all' ? listings : listings.filter((l) => l.crop === cropFilter);
  }, [listings, cropFilter]);

  const myListings = useMemo(() => listings?.filter((l) => l.session_id === sessionId) ?? [], [listings, sessionId]);

  const submit = async () => {
    if (!form.quantity_kg || !form.price_per_kg) return;
    setSaving(true);
    await supabase.from('marketplace_listings').insert({
      session_id: sessionId,
      crop: form.crop,
      variety: form.variety || null,
      quantity_kg: Number(form.quantity_kg),
      grade: form.grade,
      price_per_kg: Number(form.price_per_kg),
      district: form.district,
      contact_name: form.contact_name || null,
      contact_phone: form.contact_phone || null,
      notes: form.notes || null,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
    setShowForm(false);
    setForm(emptyForm);
    reload();
  };

  const withdraw = async (id: string) => {
    await supabase.from('marketplace_listings').delete().eq('id', id);
    reload();
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner image={PHOTOS.ctaBanner} title={t('marketplace_title')} subtitle={t('marketplace_sub')} icon={<Store className="w-5 h-5" />} />

      <div className="flex flex-wrap items-center gap-3 mb-6">
        {!showForm ? (
          <button onClick={() => setShowForm(true)} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft">
            <Plus className="w-4 h-4" /> {t('marketplace_add')}
          </button>
        ) : null}
        <select value={cropFilter} onChange={(e) => setCropFilter(e.target.value)} className="px-3 py-2 rounded-xl border border-stone-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500">
          <option value="all">{t('marketplace_all')}</option>
          {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 mb-6 animate-slide-up">
          <h3 className="font-bold text-stone-800 mb-4">{t('marketplace_add')}</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_crop')}</label>
              <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_variety')}</label>
              <input type="text" value={form.variety} onChange={(e) => setForm({ ...form, variety: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_qty')}</label>
              <input type="number" value={form.quantity_kg} onChange={(e) => setForm({ ...form, quantity_kg: e.target.value })} placeholder="kg" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_grade')}</label>
              <select value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {GRADES.map((g) => <option key={g} value={g}>{t(`grade_${g.toLowerCase()}`)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_price')}</label>
              <input type="number" value={form.price_per_kg} onChange={(e) => setForm({ ...form, price_per_kg: e.target.value })} placeholder="₹/kg" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_district')}</label>
              <select value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {DISTRICTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_contact')}</label>
              <input type="text" value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_phone')}</label>
              <input type="tel" value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div className="sm:col-span-2 lg:col-span-4">
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('marketplace_notes')}</label>
              <input type="text" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={submit} disabled={saving || !form.quantity_kg || !form.price_per_kg} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-50">
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />} {saving ? '...' : saved ? 'Posted!' : t('marketplace_save')}
            </button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-sm font-medium hover:bg-stone-100">Cancel</button>
          </div>
        </div>
      )}

      {/* Your listings */}
      {myListings.length > 0 && (
        <div className="mb-6">
          <h3 className="font-bold text-stone-800 text-sm mb-3">{t('marketplace_your_listings')}</h3>
          <div className="flex flex-wrap gap-2">
            {myListings.map((l) => (
              <div key={l.id} className="flex items-center gap-2 bg-brand-50 border border-brand-100 rounded-xl px-3 py-2 text-sm">
                <Package className="w-4 h-4 text-brand-600" />
                <span className="font-medium text-stone-700">{l.crop} · {l.quantity_kg} kg · ₹{l.price_per_kg}/kg</span>
                <button onClick={() => withdraw(l.id)} className="text-stone-300 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* All active listings */}
      <h3 className="font-bold text-stone-800 text-sm mb-3">{t('marketplace_listings')}</h3>
      {filtered.length === 0 ? (
        <EmptyState message={t('marketplace_empty')} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((l) => (
            <div key={l.id} className="bg-white rounded-2xl border border-stone-100 overflow-hidden shadow-soft hover:shadow-card transition-all group">
              <div className="relative h-32 overflow-hidden">
                <img src={CROP_PHOTO[l.crop] ?? PHOTOS.farmerField} alt={l.crop} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute top-2 start-2 flex gap-1.5">
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white/90 text-stone-700">{l.crop}</span>
                  {l.grade && <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-brand-600 text-white">Grade {l.grade}</span>}
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-lg font-bold text-stone-800">₹{l.price_per_kg}<span className="text-xs font-normal text-stone-400">/kg</span></div>
                  <div className="text-sm text-stone-500 flex items-center gap-1"><Package className="w-3.5 h-3.5" /> {l.quantity_kg} kg</div>
                </div>
                {l.variety && <div className="text-xs text-stone-500 mb-1">{t('market_variety')}: {l.variety}</div>}
                <div className="flex items-center gap-1 text-xs text-stone-500 mb-3"><MapPin className="w-3 h-3" /> {l.district}</div>
                {l.notes && <p className="text-xs text-stone-600 leading-relaxed mb-3">{l.notes}</p>}
                {l.contact_phone && (
                  <a href={`tel:${l.contact_phone}`} className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:text-brand-700">
                    <Phone className="w-3.5 h-3.5" /> {t('marketplace_contact_buyer')}
                  </a>
                )}
                {l.contact_name && <div className="text-xs text-stone-400 mt-1">{l.contact_name}</div>}
              </div>
            </div>
          ))}
        </div>
      )}

      <Disclaimer text={t('footer_disclaimer')} />
    </div>
  );
}
