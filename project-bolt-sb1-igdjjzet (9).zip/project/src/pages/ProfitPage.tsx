import { useState } from 'react';
import { Calculator, TrendingUp, TrendingDown, Save, RotateCcw, Trash2, IndianRupee, Wallet, PiggyBank } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, ProfitRecord } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { PageBanner, Disclaimer, Loading, ErrorState } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const CROPS = ['Apple', 'Saffron', 'Walnut', 'Rice', 'Maize', 'Tomato', 'Other'];

export function ProfitPage() {
  const { t } = useLanguage();
  const [crop, setCrop] = useState('Apple');
  const [area, setArea] = useState('');
  const [areaUnit, setAreaUnit] = useState('kanal');
  const [yieldKg, setYieldKg] = useState('');
  const [pricePerKg, setPricePerKg] = useState('');
  const [totalCost, setTotalCost] = useState('');
  const [result, setResult] = useState<{ revenue: number; profit: number } | null>(null);
  const [saving, setSaving] = useState(false);

  const { data: saved, loading, error, reload } = useFetch<ProfitRecord[]>(async () => {
    const { data, error } = await supabase.from('profit_records').select('*').order('created_at', { ascending: false }).limit(10);
    if (error) throw error;
    return data ?? [];
  }, []);

  const calculate = () => {
    const y = parseFloat(yieldKg) || 0;
    const p = parseFloat(pricePerKg) || 0;
    const c = parseFloat(totalCost) || 0;
    const revenue = y * p;
    const profit = revenue - c;
    setResult({ revenue, profit });
  };

  const reset = () => {
    setArea(''); setYieldKg(''); setPricePerKg(''); setTotalCost(''); setResult(null);
  };

  const save = async () => {
    if (!result) return;
    setSaving(true);
    await supabase.from('profit_records').insert({
      crop,
      land_area: area ? parseFloat(area) : null,
      area_unit: areaUnit,
      expected_yield_kg: parseFloat(yieldKg) || null,
      selling_price_per_kg: parseFloat(pricePerKg) || null,
      total_cost: parseFloat(totalCost) || null,
    });
    setSaving(false);
    reload();
  };

  const del = async (id: string) => {
    await supabase.from('profit_records').delete().eq('id', id);
    reload();
  };

  const breakEven = result && parseFloat(yieldKg) > 0
    ? (parseFloat(totalCost) || 0) / parseFloat(yieldKg)
    : null;

  const fmt = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;

  const inputClass = 'w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-400 transition-all';

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.farmerOxen}
        title={t('profit_title')}
        subtitle={t('profit_sub')}
        icon={<Calculator className="w-5 h-5" />}
      />

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="lg:col-span-3 bg-white rounded-2xl border border-stone-100 shadow-soft p-6">
          <div className="flex items-center gap-2 mb-5">
            <Wallet className="w-5 h-5 text-brand-600" />
            <h2 className="font-bold text-stone-800">{t('profit_title')}</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_crop')}</label>
              <select value={crop} onChange={(e) => setCrop(e.target.value)} className={inputClass}>
                {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_area')}</label>
                <input type="number" value={area} onChange={(e) => setArea(e.target.value)} placeholder="0" className={inputClass} />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_area_unit')}</label>
                <select value={areaUnit} onChange={(e) => setAreaUnit(e.target.value)} className={inputClass}>
                  <option value="kanal">{t('unit_kanal')}</option>
                  <option value="hectare">{t('unit_hectare')}</option>
                  <option value="acre">{t('unit_acre')}</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_yield')}</label>
              <input type="number" value={yieldKg} onChange={(e) => setYieldKg(e.target.value)} placeholder="0" className={inputClass} />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_price')}</label>
              <input type="number" value={pricePerKg} onChange={(e) => setPricePerKg(e.target.value)} placeholder="0" className={inputClass} />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">{t('profit_cost')}</label>
              <input type="number" value={totalCost} onChange={(e) => setTotalCost(e.target.value)} placeholder="0" className={inputClass} />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={calculate}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft"
              >
                <Calculator className="w-4 h-4" />
                {t('profit_calculate')}
              </button>
              <button
                onClick={reset}
                className="px-4 py-3 rounded-xl border border-stone-200 text-stone-600 text-sm font-medium hover:bg-stone-100 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Result */}
        <div className="lg:col-span-2 space-y-4">
          {result ? (
            <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 animate-slide-up">
              <div className="text-center mb-4">
                <div className="text-xs font-bold text-stone-500 uppercase tracking-wide mb-1">{t('profit_revenue')}</div>
                <div className="text-3xl font-bold text-stone-800 flex items-center justify-center gap-1">
                  <IndianRupee className="w-6 h-6" />
                  {result.revenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </div>
              </div>
              <div className={`rounded-2xl p-6 text-center ${result.profit >= 0 ? 'bg-gradient-to-br from-brand-50 to-teal-50 border border-brand-100' : 'bg-gradient-to-br from-red-50 to-rose-50 border border-red-100'}`}>
                <div className={`text-xs font-bold uppercase tracking-wide mb-2 ${result.profit >= 0 ? 'text-brand-600' : 'text-red-600'}`}>
                  {result.profit >= 0 ? t('profit_profit') : t('profit_loss')}
                </div>
                <div className={`text-4xl font-bold flex items-center justify-center gap-1.5 ${result.profit >= 0 ? 'text-brand-700' : 'text-red-700'}`}>
                  {result.profit >= 0 ? <TrendingUp className="w-7 h-7" /> : <TrendingDown className="w-7 h-7" />}
                  {fmt(Math.abs(result.profit))}
                </div>
              </div>
              {breakEven !== null && isFinite(breakEven) && (
                <div className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-stone-50 p-3">
                  <PiggyBank className="w-4 h-4 text-stone-500" />
                  <div>
                    <span className="text-xs text-stone-500">{t('profit_break_even')}: </span>
                    <span className="text-base font-bold text-stone-700 flex items-center inline-flex">
                      <IndianRupee className="w-3.5 h-3.5" />
                      {breakEven.toLocaleString('en-IN', { maximumFractionDigits: 1 })}/kg
                    </span>
                  </div>
                </div>
              )}
              <button
                onClick={save}
                disabled={saving}
                className="mt-4 w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-brand-200 text-brand-700 text-sm font-semibold hover:bg-brand-50 transition-colors disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {t('profit_save')}
              </button>
            </div>
          ) : (
            <div className="bg-stone-50 rounded-2xl border border-dashed border-stone-200 p-10 text-center">
              <Calculator className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <p className="text-sm text-stone-400">{t('profit_sub')}</p>
            </div>
          )}

          {/* Saved calculations */}
          <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-5">
            <h3 className="font-bold text-stone-800 text-sm mb-3">{t('profit_saved')}</h3>
            {loading ? (
              <Loading />
            ) : error ? (
              <ErrorState onRetry={reload} />
            ) : saved && saved.length > 0 ? (
              <div className="space-y-1">
                {saved.map((r) => {
                  const rev = (r.expected_yield_kg ?? 0) * (r.selling_price_per_kg ?? 0);
                  const prof = rev - (r.total_cost ?? 0);
                  return (
                    <div key={r.id} className="flex items-center justify-between gap-2 py-2.5 border-b border-stone-50 last:border-0">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-stone-700">{r.crop}</div>
                        <div className="text-xs text-stone-400">
                          {r.expected_yield_kg ?? '—'} kg · ₹{r.selling_price_per_kg ?? '—'}/kg
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`text-sm font-bold ${prof >= 0 ? 'text-brand-600' : 'text-red-600'}`}>
                          {fmt(prof)}
                        </span>
                        <button
                          onClick={() => del(r.id)}
                          className="p-1 text-stone-300 hover:text-red-500 transition-colors"
                          aria-label="delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-stone-400">{t('no_data')}</p>
            )}
          </div>
        </div>
      </div>

      <Disclaimer text={t('profit_disclaimer')} />
    </div>
  );
}
