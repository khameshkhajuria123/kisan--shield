import { useState, useMemo, useRef } from 'react';
import { QrCode, Save, Trash2, MapPin, Calendar, Package, Award, Snowflake, Sprout, Plus, Check, X, Printer, Download } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, CropPassport } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS, CROP_PHOTO } from '@/lib/photos';

const CROPS = ['Apple', 'Saffron', 'Rice', 'Walnut', 'Maize', 'Tomato'];
const GRADES = ['A', 'B', 'C'];
const STORAGE_TYPES = ['cold', 'ambient', 'dry', 'none'];
const DISTRICTS = ['Srinagar', 'Baramulla', 'Shopian', 'Anantnag', 'Pulwama', 'Kulgam', 'Budgam', 'Kupwara', 'Ganderbal', 'Bandipora', 'Jammu', 'Udhampur', 'Kathua', 'Doda'];

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

function buildQrData(passport: Partial<CropPassport>): string {
  const parts = [
    `BATCH:${passport.batch_id ?? ''}`,
    `CROP:${passport.crop ?? ''}`,
    `VARIETY:${passport.variety ?? ''}`,
    `FARM:${passport.farm_name ?? ''}`,
    `DISTRICT:${passport.district ?? ''}`,
    `HARVEST:${passport.harvest_date ?? ''}`,
    `QTY:${passport.quantity_kg ?? ''}kg`,
    `GRADE:${passport.grade ?? ''}`,
    `STORAGE:${passport.storage_type ?? ''}`,
  ];
  return parts.join('|');
}

export function PassportPage() {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [selected, setSelected] = useState<CropPassport | null>(null);
  const [cropFilter, setCropFilter] = useState('all');
  const sessionId = getSessionId();
  const printRef = useRef<HTMLDivElement>(null);

  const emptyForm = {
    crop: 'Apple',
    variety: '',
    farm_name: '',
    district: 'Srinagar',
    harvest_date: new Date().toISOString().split('T')[0],
    quantity_kg: '',
    grade: 'A',
    storage_type: 'cold',
    storage_date: '',
    certifications: '',
    quality_notes: '',
  };
  const [form, setForm] = useState(emptyForm);

  const { data: passports, loading, error, reload } = useFetch<CropPassport[]>(async () => {
    const { data } = await supabase
      .from('crop_passports')
      .select('*')
      .order('created_at', { ascending: false });
    return data ?? [];
  }, []);

  const filtered = useMemo(() => {
    if (!passports) return [];
    return cropFilter === 'all' ? passports : passports.filter((p) => p.crop === cropFilter);
  }, [passports, cropFilter]);

  const myPassports = useMemo(() => passports?.filter((p) => p.session_id === sessionId) ?? [], [passports, sessionId]);

  const submit = async () => {
    setSaving(true);
    const tempBatch = `KS-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    const qrData = buildQrData({
      batch_id: tempBatch,
      crop: form.crop,
      variety: form.variety,
      farm_name: form.farm_name,
      district: form.district,
      harvest_date: form.harvest_date,
      quantity_kg: form.quantity_kg ? Number(form.quantity_kg) : null,
      grade: form.grade,
      storage_type: form.storage_type,
    });
    const { data } = await supabase.from('crop_passports').insert({
      session_id: sessionId,
      crop: form.crop,
      variety: form.variety || null,
      farm_name: form.farm_name || null,
      district: form.district,
      harvest_date: form.harvest_date,
      quantity_kg: form.quantity_kg ? Number(form.quantity_kg) : null,
      grade: form.grade,
      storage_type: form.storage_type,
      storage_date: form.storage_date || null,
      certifications: form.certifications || null,
      quality_notes: form.quality_notes || null,
      qr_code: qrData,
    }).select().single();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
    setShowForm(false);
    setForm(emptyForm);
    reload();
    if (data) setSelected(data);
  };

  const remove = async (id: string) => {
    await supabase.from('crop_passports').delete().eq('id', id);
    setSelected(null);
    reload();
  };

  const handlePrint = () => {
    if (!printRef.current) return;
    const win = window.open('', '_blank', 'width=600,height=800');
    if (!win) return;
    win.document.write(printRef.current.innerHTML);
    win.document.close();
    win.print();
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner image={PHOTOS.appleHarvest} title={t('passport_title')} subtitle={t('passport_sub')} icon={<QrCode className="w-5 h-5" />} />

      {/* Detail modal */}
      {selected && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-stone-800 text-lg">{t('passport_detail')}</h3>
              <button onClick={() => setSelected(null)} className="p-2 rounded-lg hover:bg-stone-100"><X className="w-5 h-5 text-stone-500" /></button>
            </div>

            <div ref={printRef} className="space-y-4">
              {/* QR + batch header */}
              <div className="flex items-start gap-4 rounded-2xl border border-stone-100 p-4">
                <div className="shrink-0">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(selected.qr_code ?? selected.batch_id)}`}
                    alt="QR code"
                    className="w-32 h-32 rounded-xl border border-stone-100"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-stone-400 font-medium mb-1">{t('passport_batch')}</div>
                  <div className="font-mono font-bold text-stone-800 text-sm break-all mb-2">{selected.batch_id}</div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-brand-50 text-brand-700">{selected.crop}</span>
                    {selected.grade && <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700">Grade {selected.grade}</span>}
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${selected.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'}`}>
                      {selected.status === 'active' ? t('passport_status_active') : t('passport_status_sold')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Journey timeline */}
              <div>
                <h4 className="font-bold text-stone-700 text-sm mb-3">{t('passport_journey')}</h4>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-brand-50 flex items-center justify-center shrink-0"><Sprout className="w-4 h-4 text-brand-600" /></div>
                    <div>
                      <div className="text-xs text-stone-400">Farm origin</div>
                      <div className="text-sm font-medium text-stone-700">{selected.farm_name || selected.district || '—'}</div>
                      {selected.district && <div className="text-xs text-stone-500 flex items-center gap-1"><MapPin className="w-3 h-3" /> {selected.district}</div>}
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center shrink-0"><Calendar className="w-4 h-4 text-amber-600" /></div>
                    <div>
                      <div className="text-xs text-stone-400">Harvest date</div>
                      <div className="text-sm font-medium text-stone-700">{new Date(selected.harvest_date).toLocaleDateString('en-IN')}</div>
                    </div>
                  </div>
                  {selected.quantity_kg && (
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0"><Package className="w-4 h-4 text-blue-600" /></div>
                      <div>
                        <div className="text-xs text-stone-400">Quantity</div>
                        <div className="text-sm font-medium text-stone-700">{selected.quantity_kg} kg</div>
                      </div>
                    </div>
                  )}
                  {selected.storage_type && selected.storage_type !== 'none' && (
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-cyan-50 flex items-center justify-center shrink-0"><Snowflake className="w-4 h-4 text-cyan-600" /></div>
                      <div>
                        <div className="text-xs text-stone-400">Storage</div>
                        <div className="text-sm font-medium text-stone-700 capitalize">{t(`storage_${selected.storage_type}`)}{selected.storage_date ? ` · ${new Date(selected.storage_date).toLocaleDateString('en-IN')}` : ''}</div>
                      </div>
                    </div>
                  )}
                  {selected.certifications && (
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0"><Award className="w-4 h-4 text-emerald-600" /></div>
                      <div>
                        <div className="text-xs text-stone-400">Certifications</div>
                        <div className="text-sm font-medium text-stone-700">{selected.certifications}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {selected.quality_notes && (
                <div className="rounded-xl bg-stone-50 border border-stone-100 p-3">
                  <div className="text-xs font-bold text-stone-500 mb-1">{t('passport_quality')}</div>
                  <p className="text-sm text-stone-700">{selected.quality_notes}</p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 mt-5 pt-4 border-t border-stone-100">
              <button onClick={handlePrint} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-100 text-stone-700 text-sm font-medium hover:bg-stone-200 transition-colors">
                <Printer className="w-4 h-4" /> {t('passport_print')}
              </button>
              <a
                href={`https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(selected.qr_code ?? selected.batch_id)}`}
                download="qr-code.png"
                target="_blank"
                rel="noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
              >
                <Download className="w-4 h-4" /> {t('passport_download')}
              </a>
              {selected.session_id === sessionId && (
                <button onClick={() => remove(selected.id)} className="px-3 py-2.5 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Form */}
      {showForm ? (
        <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 mb-6 animate-slide-up">
          <h3 className="font-bold text-stone-800 mb-4">{t('passport_add')}</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_crop')}</label>
              <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_variety')}</label>
              <input type="text" value={form.variety} onChange={(e) => setForm({ ...form, variety: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_farm')}</label>
              <input type="text" value={form.farm_name} onChange={(e) => setForm({ ...form, farm_name: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_district')}</label>
              <select value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {DISTRICTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_harvest')}</label>
              <input type="date" value={form.harvest_date} onChange={(e) => setForm({ ...form, harvest_date: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_qty')}</label>
              <input type="number" value={form.quantity_kg} onChange={(e) => setForm({ ...form, quantity_kg: e.target.value })} placeholder="kg" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_grade')}</label>
              <select value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {GRADES.map((g) => <option key={g} value={g}>{t(`grade_${g.toLowerCase()}`)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_storage')}</label>
              <select value={form.storage_type} onChange={(e) => setForm({ ...form, storage_type: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {STORAGE_TYPES.map((s) => <option key={s} value={s}>{t(`storage_${s}`)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_storage_date')}</label>
              <input type="date" value={form.storage_date} onChange={(e) => setForm({ ...form, storage_date: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_certs')}</label>
              <input type="text" value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} placeholder="e.g. Organic, GAP" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('passport_quality')}</label>
              <input type="text" value={form.quality_notes} onChange={(e) => setForm({ ...form, quality_notes: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-50">
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />} {saving ? '...' : saved ? 'Created!' : t('passport_save')}
            </button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-sm font-medium hover:bg-stone-100">Cancel</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setShowForm(true)} className="mb-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft">
          <Plus className="w-4 h-4" /> {t('passport_add')}
        </button>
      )}

      {/* Filter */}
      {passports && passports.length > 0 && (
        <select value={cropFilter} onChange={(e) => setCropFilter(e.target.value)} className="mb-4 px-3 py-2 rounded-xl border border-stone-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500">
          <option value="all">{t('passport_all')}</option>
          {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      )}

      {/* Your passports */}
      {myPassports.length > 0 && (
        <div className="mb-4">
          <h3 className="font-bold text-stone-800 text-sm mb-2">{t('passport_your')}</h3>
          <div className="flex flex-wrap gap-2">
            {myPassports.map((p) => (
              <div key={p.id} className="flex items-center gap-2 bg-brand-50 border border-brand-100 rounded-xl px-3 py-2 text-sm">
                <QrCode className="w-4 h-4 text-brand-600" />
                <span className="font-mono font-medium text-stone-700 text-xs">{p.batch_id}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Passport cards */}
      {filtered.length === 0 ? (
        <EmptyState message={t('passport_empty')} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <div
              key={p.id}
              onClick={() => setSelected(p)}
              className="bg-white rounded-2xl border border-stone-100 overflow-hidden shadow-soft hover:shadow-card transition-all cursor-pointer group"
            >
              <div className="relative h-32 overflow-hidden">
                <img src={CROP_PHOTO[p.crop] ?? PHOTOS.farmerField} alt={p.crop} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute top-2 start-2 flex gap-1.5">
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white/90 text-stone-700">{p.crop}</span>
                  {p.grade && <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500 text-white">Grade {p.grade}</span>}
                </div>
                <div className="absolute bottom-2 start-2 flex items-center gap-1 text-white/90 text-xs font-mono">
                  <QrCode className="w-3 h-3" /> {p.batch_id}
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1 text-xs text-stone-500"><MapPin className="w-3 h-3" /> {p.district}</div>
                  <div className="text-xs text-stone-400">{new Date(p.harvest_date).toLocaleDateString('en-IN')}</div>
                </div>
                {p.quantity_kg && (
                  <div className="text-sm text-stone-600 flex items-center gap-1.5"><Package className="w-3.5 h-3.5 text-stone-400" /> {p.quantity_kg} kg</div>
                )}
                <div className="mt-3 flex items-center justify-between">
                  <div className={`text-xs font-semibold px-2 py-0.5 rounded-full ${p.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'}`}>
                    {p.status === 'active' ? t('passport_status_active') : t('passport_status_sold')}
                  </div>
                  <div className="text-xs text-brand-600 font-semibold group-hover:underline">{t('passport_scan')} →</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Disclaimer text={t('footer_disclaimer')} />
    </div>
  );
}
