import { Landmark, ExternalLink, FileText, CheckCircle2, Calendar, IndianRupee, ArrowUpRight } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, GovtScheme } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const CATEGORY_COLOR: Record<string, string> = {
  'Income Support': 'bg-brand-50 text-brand-700',
  'Crop Insurance': 'bg-amber-50 text-amber-700',
  Credit: 'bg-sky-50 text-sky-700',
  Irrigation: 'bg-cyan-50 text-cyan-700',
  Soil: 'bg-stone-100 text-stone-700',
  'Market Support': 'bg-violet-50 text-violet-700',
  Horticulture: 'bg-rose-50 text-rose-700',
  Seeds: 'bg-lime-50 text-lime-700',
  'Disaster Relief': 'bg-red-50 text-red-700',
  Market: 'bg-teal-50 text-teal-700',
};

export function SchemesPage() {
  const { t } = useLanguage();

  const { data, loading, error, reload } = useFetch<GovtScheme[]>(async () => {
    const { data, error } = await supabase.from('govt_schemes').select('*').order('name');
    if (error) throw error;
    return data ?? [];
  }, []);

  if (loading) return <Loading />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.farmerField}
        title={t('schemes_title')}
        subtitle={t('schemes_sub')}
        icon={<Landmark className="w-5 h-5" />}
      />

      {(!data || data.length === 0) ? (
        <EmptyState />
      ) : (
        <div className="grid sm:grid-cols-2 gap-5 stagger">
          {data.map((s) => (
            <div key={s.id} className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 card-hover flex flex-col">
              <div className="flex items-start justify-between gap-3 mb-3">
                <h3 className="font-bold text-stone-800 text-lg leading-snug">{s.name}</h3>
                {s.category && (
                  <span className={`px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 ${CATEGORY_COLOR[s.category] ?? 'bg-stone-100 text-stone-700'}`}>
                    {s.category}
                  </span>
                )}
              </div>
              {s.agency && <p className="text-xs text-stone-500 mb-4 font-medium">{s.agency}</p>}

              {s.benefits && (
                <div className="mb-3 rounded-xl bg-stone-50/70 p-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <IndianRupee className="w-3.5 h-3.5 text-brand-600" />
                    {t('schemes_benefits')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{s.benefits}</p>
                </div>
              )}

              {s.eligibility && (
                <div className="mb-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <CheckCircle2 className="w-3.5 h-3.5 text-brand-600" />
                    {t('schemes_eligibility')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{s.eligibility}</p>
                </div>
              )}

              {s.documents && (
                <div className="mb-3">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <FileText className="w-3.5 h-3.5 text-brand-600" />
                    {t('schemes_documents')}
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed">{s.documents}</p>
                </div>
              )}

              {s.deadline && (
                <div className="mb-4">
                  <div className="text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                    <Calendar className="w-3.5 h-3.5 text-brand-600" />
                    {t('schemes_deadline')}
                  </div>
                  <p className="text-sm text-stone-600">{s.deadline}</p>
                </div>
              )}

              {s.application_url && (
                <a
                  href={s.application_url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="mt-auto inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft group"
                >
                  {t('schemes_apply')}
                  <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </a>
              )}
            </div>
          ))}
        </div>
      )}

      <Disclaimer text={t('schemes_sub')} />
    </div>
  );
}
