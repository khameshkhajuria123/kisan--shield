import { useMemo, useState } from 'react';
import { CloudRain, Snowflake, Wind, AlertTriangle, Droplets, CloudLightning, RefreshCw, MapPin } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, WeatherAlert } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const SEVERITY_STYLE: Record<string, string> = {
  Severe: 'bg-red-500 text-white',
  Moderate: 'bg-amber-500 text-white',
  Light: 'bg-sky-500 text-white',
  Watch: 'bg-violet-500 text-white',
};

const TYPE_ICON: Record<string, typeof CloudRain> = {
  Frost: Snowflake,
  Snow: Snowflake,
  Rain: CloudRain,
  Hailstorm: CloudLightning,
  Wind: Wind,
};

const TYPE_BG: Record<string, string> = {
  Frost: 'from-sky-400 to-blue-500',
  Snow: 'from-sky-400 to-cyan-500',
  Rain: 'from-blue-400 to-indigo-500',
  Hailstorm: 'from-violet-400 to-purple-500',
  Wind: 'from-teal-400 to-cyan-500',
};

export function WeatherPage() {
  const { t } = useLanguage();
  const [locationFilter, setLocationFilter] = useState('all');

  const { data: alerts, loading, error, reload } = useFetch<WeatherAlert[]>(async () => {
    const { data, error } = await supabase
      .from('weather_alerts')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  }, []);

  const locations = useMemo(() => {
    const set = new Set(alerts?.map((a) => a.location) ?? []);
    return Array.from(set).sort();
  }, [alerts]);

  const filtered = useMemo(() => {
    if (locationFilter === 'all') return alerts ?? [];
    return (alerts ?? []).filter((a) => a.location === locationFilter);
  }, [alerts, locationFilter]);

  const refreshWeather = async () => {
    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/weather`;
      await fetch(url, {
        headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
      });
    } catch {
      // ignore — we still reload cached
    }
    reload();
  };

  if (loading) return <Loading />;
  if (error) return <ErrorState onRetry={reload} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.riceTerrace}
        title={t('weather_title')}
        subtitle={t('weather_sub')}
        icon={<CloudRain className="w-5 h-5" />}
      />

      <div className="flex items-center justify-end mb-4">
        <button
          onClick={refreshWeather}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shrink-0 shadow-soft"
        >
          <RefreshCw className="w-4 h-4" />
          {t('retry')}
        </button>
      </div>

      {/* Location filter */}
      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setLocationFilter('all')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            locationFilter === 'all' ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          {t('weather_all')}
        </button>
        {locations.map((loc) => (
          <button
            key={loc}
            onClick={() => setLocationFilter(loc)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              locationFilter === loc ? 'bg-brand-600 text-white shadow-soft' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            {loc}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState message={t('weather_none')} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 stagger">
          {filtered.map((a) => {
            const Icon = TYPE_ICON[a.alert_type] ?? AlertTriangle;
            const sevStyle = SEVERITY_STYLE[a.severity ?? ''] ?? 'bg-stone-500 text-white';
            const sevLabel = a.severity ? t(`weather_severity_${a.severity.toLowerCase()}`) : a.severity;
            const typeBg = TYPE_BG[a.alert_type] ?? 'from-stone-400 to-stone-500';
            return (
              <div key={a.id} className="bg-white rounded-2xl border border-stone-100 shadow-soft overflow-hidden card-hover">
                {/* Colored header strip */}
                <div className={`h-1.5 bg-gradient-to-r ${typeBg}`} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${typeBg} flex items-center justify-center shadow-sm`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-stone-800">{a.alert_type}</div>
                        <div className="text-xs text-stone-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3" />
                          {a.location}{a.district ? `, ${a.district}` : ''}
                        </div>
                      </div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${sevStyle}`}>
                      {sevLabel}
                    </span>
                  </div>
                  <p className="text-sm text-stone-600 leading-relaxed mb-3">{a.description}</p>
                  {a.recommendation && (
                    <div className="rounded-xl bg-brand-50 border border-brand-100 p-3">
                      <div className="text-xs font-bold text-brand-700 mb-1 flex items-center gap-1.5 uppercase tracking-wide">
                        <Droplets className="w-3.5 h-3.5" />
                        {t('weather_reco')}
                      </div>
                      <p className="text-xs text-brand-900 leading-relaxed">{a.recommendation}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Disclaimer text={t('weather_sub')} />
    </div>
  );
}
