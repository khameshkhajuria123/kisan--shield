import { useState, useRef, useEffect } from 'react';
import { Bot, Send, Mic, MicOff, Trash2, User, Sparkles, Loader2 } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, ChatMessage } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

type Msg = { role: 'user' | 'assistant'; text: string; crop?: string | null };

const SUGGESTIONS = [
  'What diseases affect apple trees?',
  'When should I harvest saffron?',
  'What are the latest weather alerts?',
  'What is the mandi price of apple?',
  'What government schemes are available?',
  'How do I protect my crops from frost?',
];

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

export function AssistantPage() {
  const { t, lang } = useLanguage();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Msg[]>([]);
  const [thinking, setThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recRef = useRef<any>(null);
  const sessionId = getSessionId();

  const { data: history, reload } = useFetch<ChatMessage[]>(async () => {
    const { data } = await supabase
      .from('ai_chat_history')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: true })
      .limit(20);
    return data ?? [];
  }, []);

  useEffect(() => {
    if (history && history.length > 0 && messages.length === 0) {
      setMessages(history.map((h) => ({ role: 'assistant' as const, text: h.answer, crop: h.crop })));
      // Prepend user messages — reconstruct from history
      const combined: Msg[] = [];
      for (const h of history) {
        combined.push({ role: 'user', text: h.question });
        combined.push({ role: 'assistant', text: h.answer, crop: h.crop });
      }
      setMessages(combined);
    } else if ((!history || history.length === 0) && messages.length === 0) {
      setMessages([{ role: 'assistant', text: t('assistant_welcome') }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [history]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  const send = async (text?: string) => {
    const q = (text ?? input).trim();
    if (!q || thinking) return;
    setError(null);
    setInput('');
    setMessages((m) => [...m, { role: 'user', text: q }]);
    setThinking(true);

    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-assistant`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question: q, lang, session_id: sessionId }),
      });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMessages((m) => [...m, { role: 'assistant', text: data.answer, crop: data.crop }]);
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
      setMessages((m) => [...m, { role: 'assistant', text: 'Sorry, I could not process your question. Please try again.' }]);
    } finally {
      setThinking(false);
    }
  };

  const startVoice = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setError('Voice input is not supported in your browser. Try typing your question.');
      return;
    }
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = lang === 'hi' ? 'hi-IN' : lang === 'ur' ? 'ur-IN' : 'en-IN';
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      send(transcript);
    };
    rec.onerror = () => {
      setListening(false);
      setError('Voice input failed. Please try again or type your question.');
    };
    rec.onend = () => setListening(false);
    rec.start();
    recRef.current = rec;
    setListening(true);
  };

  const clearChat = async () => {
    await supabase.from('ai_chat_history').delete().eq('session_id', sessionId);
    setMessages([{ role: 'assistant', text: t('assistant_welcome') }]);
    reload();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.farmerField}
        title={t('assistant_title')}
        subtitle={t('assistant_sub')}
        icon={<Bot className="w-5 h-5" />}
      />

      {/* Chat container */}
      <div className="bg-white rounded-2xl border border-stone-100 shadow-soft flex flex-col h-[600px] overflow-hidden">
        {/* Header bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-100 bg-gradient-to-r from-brand-50 to-teal-50">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shadow-sm">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-stone-800 text-sm">KisanShield AI</div>
              <div className="text-xs text-brand-600 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse" />
                Online
              </div>
            </div>
          </div>
          {messages.length > 1 && (
            <button
              onClick={clearChat}
              className="p-2 rounded-lg text-stone-400 hover:text-red-500 hover:bg-red-50 transition-colors"
              aria-label={t('assistant_clear')}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-2.5 ${m.role === 'user' ? 'flex-row-reverse' : ''} animate-fade-in`}>
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                m.role === 'user' ? 'bg-stone-200' : 'bg-gradient-to-br from-brand-500 to-brand-700'
              }`}>
                {m.role === 'user' ? <User className="w-4 h-4 text-stone-600" /> : <Bot className="w-4 h-4 text-white" />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                m.role === 'user'
                  ? 'bg-brand-600 text-white rounded-tr-sm'
                  : 'bg-stone-50 text-stone-700 rounded-tl-sm border border-stone-100'
              }`}>
                <p className="whitespace-pre-wrap">{m.text}</p>
                {m.crop && m.role === 'assistant' && (
                  <span className="inline-block mt-2 text-xs px-2 py-0.5 rounded-full bg-brand-100 text-brand-700 font-medium">
                    {m.crop}
                  </span>
                )}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex gap-2.5 animate-fade-in">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-stone-50 border border-stone-100 rounded-2xl rounded-tl-sm px-4 py-3">
                <div className="flex items-center gap-2 text-stone-500">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">{t('assistant_thinking')}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        {messages.length <= 1 && !thinking && (
          <div className="px-4 pb-2 flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="text-xs px-3 py-1.5 rounded-full bg-stone-100 text-stone-600 hover:bg-brand-50 hover:text-brand-700 transition-colors border border-stone-200"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {/* Input bar */}
        <div className="border-t border-stone-100 p-3">
          {error && (
            <div className="mb-2 text-xs text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</div>
          )}
          <div className="flex items-center gap-2">
            <button
              onClick={startVoice}
              className={`p-2.5 rounded-xl transition-colors shrink-0 ${
                listening ? 'bg-red-500 text-white animate-pulse' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
              aria-label={t('assistant_voice')}
            >
              {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder={listening ? t('assistant_listening') : t('assistant_placeholder')}
              className="flex-1 px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-400 transition-all"
            />
            <button
              onClick={() => send()}
              disabled={!input.trim() || thinking}
              className="p-2.5 rounded-xl bg-brand-600 text-white hover:bg-brand-700 transition-colors shrink-0 disabled:opacity-40 disabled:cursor-not-allowed shadow-soft"
              aria-label={t('assistant_send')}
            >
              <Send className="w-5 h-5 rtl:rotate-180" />
            </button>
          </div>
        </div>
      </div>

      <Disclaimer text={t('disease_disclaimer')} />
    </div>
  );
}
