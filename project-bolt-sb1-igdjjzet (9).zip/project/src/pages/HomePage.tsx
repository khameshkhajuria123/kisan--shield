import {
  CloudRain,
  Leaf,
  CalendarDays,
  TrendingUp,
  Landmark,
  Calculator,
  Sprout,
  ArrowRight,
  Droplets,
  ShieldCheck,
  Sun,
  Globe2,
  Quote,
  Bot,
  ShieldAlert,
  MapPin,
  ClipboardList,
  Store,
  QrCode,
} from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { Page } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { SectionTitle } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

type Stats = {
  alertCount: number;
  cropCount: number;
  schemeCount: number;
};

export function HomePage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { t } = useLanguage();

  const { data: stats } = useFetch<Stats>(async () => {
    const [a, s] = await Promise.all([
      supabase.from('weather_alerts').select('*', { count: 'exact', head: true }),
      supabase.from('govt_schemes').select('*', { count: 'exact', head: true }),
    ]);
    const { data: crops } = await supabase.from('crop_calendar').select('crop');
    const cropSet = new Set(crops?.map((r) => r.crop) ?? []);
    return {
      alertCount: a.count ?? 0,
      cropCount: cropSet.size,
      schemeCount: s.count ?? 0,
    };
  }, []);

  const features: { page: Page; icon: typeof CloudRain; titleKey: string; descKey: string; color: string; bg: string; img: string }[] = [
    { page: 'weather', icon: CloudRain, titleKey: 'feat_weather_t', descKey: 'feat_weather_d', color: 'from-sky-500 to-blue-600', bg: 'bg-sky-50', img: PHOTOS.riceTerrace },
    { page: 'disease', icon: Leaf, titleKey: 'feat_disease_t', descKey: 'feat_disease_d', color: 'from-rose-500 to-red-600', bg: 'bg-rose-50', img: PHOTOS.appleTree },
    { page: 'calendar', icon: CalendarDays, titleKey: 'feat_calendar_t', descKey: 'feat_calendar_d', color: 'from-amber-500 to-orange-600', bg: 'bg-amber-50', img: PHOTOS.saffronField },
    { page: 'market', icon: TrendingUp, titleKey: 'feat_market_t', descKey: 'feat_market_d', color: 'from-brand-500 to-teal-600', bg: 'bg-brand-50', img: PHOTOS.appleHarvest },
    { page: 'schemes', icon: Landmark, titleKey: 'feat_schemes_t', descKey: 'feat_schemes_d', color: 'from-violet-500 to-purple-600', bg: 'bg-violet-50', img: PHOTOS.farmerField },
    { page: 'profit', icon: Calculator, titleKey: 'feat_profit_t', descKey: 'feat_profit_d', color: 'from-cyan-500 to-blue-600', bg: 'bg-cyan-50', img: PHOTOS.farmerOxen },
    { page: 'assistant', icon: Bot, titleKey: 'nav_assistant', descKey: 'assistant_sub', color: 'from-brand-500 to-brand-700', bg: 'bg-brand-50', img: PHOTOS.farmerField },
    { page: 'risk', icon: ShieldAlert, titleKey: 'nav_risk', descKey: 'risk_sub', color: 'from-amber-500 to-red-600', bg: 'bg-amber-50', img: PHOTOS.riceTerrace },
    { page: 'location', icon: MapPin, titleKey: 'nav_location', descKey: 'location_sub', color: 'from-emerald-500 to-teal-600', bg: 'bg-emerald-50', img: PHOTOS.appleTree },
    { page: 'soil', icon: Droplets, titleKey: 'nav_soil', descKey: 'soil_sub', color: 'from-blue-500 to-cyan-600', bg: 'bg-blue-50', img: PHOTOS.ricePlant },
    { page: 'records', icon: ClipboardList, titleKey: 'nav_records', descKey: 'records_sub', color: 'from-stone-500 to-stone-700', bg: 'bg-stone-100', img: PHOTOS.womenHarvest },
    { page: 'marketplace', icon: Store, titleKey: 'nav_marketplace', descKey: 'marketplace_sub', color: 'from-orange-500 to-red-600', bg: 'bg-orange-50', img: PHOTOS.ctaBanner },
    { page: 'passport', icon: QrCode, titleKey: 'nav_passport', descKey: 'passport_sub', color: 'from-violet-500 to-purple-600', bg: 'bg-violet-50', img: PHOTOS.appleTree },
  ];

  const statCards = [
    { value: stats?.alertCount ?? '—', label: t('home_stat_alerts'), icon: CloudRain, color: 'text-sky-600', bg: 'bg-sky-50' },
    { value: stats?.cropCount ?? '—', label: t('home_stat_crops'), icon: Sprout, color: 'text-brand-600', bg: 'bg-brand-50' },
    { value: stats?.schemeCount ?? '—', label: t('home_stat_schemes'), icon: Landmark, color: 'text-violet-600', bg: 'bg-violet-50' },
    { value: 5, label: t('home_stat_langs'), icon: Globe2, color: 'text-teal-600', bg: 'bg-teal-50' },
  ];

  const pillars: { icon: typeof ShieldCheck; title: string; desc: string; img: string }[] = [
    { icon: ShieldCheck, title: t('feat_weather_t'), desc: t('feat_weather_d'), img: PHOTOS.riceTerrace },
    { icon: Leaf, title: t('feat_disease_t'), desc: t('feat_disease_d'), img: PHOTOS.appleTree },
    { icon: TrendingUp, title: t('feat_market_t'), desc: t('feat_market_d'), img: PHOTOS.appleHarvest },
  ];

  const gallery: { img: string; label: string; sub: string }[] = [
    { img: PHOTOS.appleHarvest, label: 'Apple', sub: 'Harvest Season' },
    { img: PHOTOS.saffronField, label: 'Saffron', sub: 'Pampore Bloom' },
    { img: PHOTOS.riceTerrace, label: 'Rice', sub: 'Paddy Fields' },
    { img: PHOTOS.walnut, label: 'Walnut', sub: 'Dry Fruit' },
    { img: PHOTOS.farmerField, label: 'Maize', sub: 'Monsoon Crop' },
    { img: PHOTOS.womenHarvest, label: 'Community', sub: ' collective Farming' },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden min-h-[600px] flex items-center">
        <div className="absolute inset-0">
          <img
            src={PHOTOS.heroApple}
            alt="Kashmir orchard farmer harvesting apples"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-brand-950/85 via-brand-900/75 to-stone-900/85" />
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 25% 30%, white 1px, transparent 1px), radial-gradient(circle at 75% 60%, white 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 sm:py-28 w-full">
          <div className="max-w-2xl animate-slide-up">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass text-sm font-medium mb-6 text-white">
              <span className="w-2 h-2 rounded-full bg-wheat-400 animate-pulse" />
              {t('app_tagline')}
            </div>
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] text-white mb-5 tracking-tight">
              {t('home_hero_title')}
            </h1>
            <p className="text-lg sm:text-xl text-white/80 leading-relaxed mb-8 max-w-xl">
              {t('home_hero_sub')}
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('weather')}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-brand-800 font-semibold text-base shadow-xl hover:shadow-2xl hover:scale-[1.03] transition-all"
              >
                {t('home_hero_cta')}
                <ArrowRight className="w-5 h-5 rtl:rotate-180" />
              </button>
              <button
                onClick={() => onNavigate('profit')}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl glass text-white font-semibold text-base hover:bg-white/20 transition-all"
              >
                <Calculator className="w-5 h-5" />
                {t('nav_profit')}
              </button>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 inset-x-0 h-16 bg-gradient-to-t from-stone-50 to-transparent" />
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 -mt-10 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
          {statCards.map((s, i) => (
            <div key={i} className="bg-white rounded-2xl shadow-card border border-stone-100 p-5 card-hover">
              <div className={`w-11 h-11 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <div className="text-3xl font-bold text-stone-800 tracking-tight">{s.value}</div>
              <div className="text-xs text-stone-500 mt-1 font-medium">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Three pillars with photos */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-20">
        <SectionTitle
          eyebrow="Why KisanShield"
          title={t('home_features_title')}
          subtitle={t('home_features_sub')}
          center
        />
        <div className="grid sm:grid-cols-3 gap-6 stagger">
          {pillars.map((p, i) => (
            <div key={i} className="bg-white rounded-2xl border border-stone-100 shadow-soft overflow-hidden card-hover group">
              {/* Photo */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={p.img}
                  alt={p.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute bottom-3 start-3">
                  <div className="w-10 h-10 rounded-xl bg-white/90 backdrop-blur flex items-center justify-center shadow-md">
                    <p.icon className="w-5 h-5 text-brand-700" />
                  </div>
                </div>
              </div>
              {/* Content */}
              <div className="p-5">
                <h3 className="font-bold text-stone-800 text-lg mb-2">{p.title}</h3>
                <p className="text-sm text-stone-600 leading-relaxed">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Feature grid with images */}
      <section className="bg-gradient-to-b from-stone-100/50 to-stone-50 py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <SectionTitle
            eyebrow="Tools & Features"
            title={t('home_features_title')}
            subtitle={t('home_features_sub')}
            center
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 stagger">
            {features.map((f) => (
              <button
                key={f.page}
                onClick={() => onNavigate(f.page)}
                className="group text-start bg-white rounded-2xl border border-stone-100 shadow-soft hover:shadow-card card-hover overflow-hidden"
              >
                {/* Photo header */}
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={f.img}
                    alt={t(f.titleKey)}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className={`absolute top-3 start-3 w-11 h-11 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-transform`}>
                    <f.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                {/* Content */}
                <div className="p-5 relative">
                  <h3 className="font-bold text-stone-800 text-lg mb-1.5">{t(f.titleKey)}</h3>
                  <p className="text-sm text-stone-600 leading-relaxed line-clamp-2">{t(f.descKey)}</p>
                  <div className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0">
                    {t('home_hero_cta')}
                    <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Crop gallery */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-20">
        <SectionTitle
          eyebrow="Kashmir Crops"
          title="Crops We Support"
          subtitle="From apple orchards to saffron fields — tailored guidance for every major Kashmir crop."
          center
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 stagger">
          {gallery.map((g, i) => (
            <div key={i} className="group relative rounded-2xl overflow-hidden shadow-soft aspect-[3/4] cursor-pointer" onClick={() => onNavigate('calendar')}>
              <img
                src={g.img}
                alt={g.label}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-3">
                <div className="font-bold text-white text-sm">{g.label}</div>
                <div className="text-xs text-white/70">{g.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Farmer testimonial with photo */}
      <section className="bg-gradient-to-b from-stone-100/50 to-stone-50 py-16 sm:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Photo */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-card">
                <img
                  src={PHOTOS.farmerPortrait1}
                  alt="Kashmir farmer"
                  className="w-full h-[420px] object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-950/30 to-transparent" />
              </div>
              {/* Floating quote badge */}
              <div className="absolute -bottom-4 -end-4 bg-white rounded-2xl shadow-card p-4 max-w-[200px] hidden sm:block">
                <Quote className="w-6 h-6 text-brand-500 mb-1" />
                <p className="text-xs text-stone-600 leading-relaxed font-medium">
                  "KisanShield helped me save my apple orchard from frost damage."
                </p>
              </div>
            </div>
            {/* Text */}
            <div className="animate-slide-up">
              <div className="text-xs font-bold tracking-widest uppercase text-brand-600 mb-2">
                For Every Kashmiri Farmer
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-stone-800 tracking-tight mb-4 leading-tight">
                {t('home_hero_title')}
              </h2>
              <p className="text-stone-600 leading-relaxed mb-6">
                {t('footer_about_text')}
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => onNavigate('disease')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft"
                >
                  <Leaf className="w-4 h-4" />
                  {t('nav_disease')}
                </button>
                <button
                  onClick={() => onNavigate('schemes')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-stone-200 text-stone-700 text-sm font-semibold hover:bg-stone-100 transition-colors"
                >
                  <Landmark className="w-4 h-4" />
                  {t('nav_schemes')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA banner with photo background */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="relative overflow-hidden rounded-3xl min-h-[280px] flex items-center justify-center">
          <img
            src={PHOTOS.ctaBanner}
            alt="Orchard aerial view"
            className="absolute inset-0 w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-brand-900/90 to-brand-950/95" />
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 30% 40%, white 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
          <div className="relative text-center px-6 py-12 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-sm font-medium mb-4 text-white">
              <Sun className="w-4 h-4 text-wheat-400" />
              {t('app_tagline')}
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold text-white mb-4 leading-tight">
              {t('home_hero_title')}
            </h2>
            <p className="text-white/80 mb-6 leading-relaxed">
              {t('home_hero_sub')}
            </p>
            <button
              onClick={() => onNavigate('calendar')}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-brand-800 font-semibold text-base shadow-xl hover:scale-[1.03] transition-all"
            >
              {t('nav_calendar')}
              <ArrowRight className="w-5 h-5 rtl:rotate-180" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
