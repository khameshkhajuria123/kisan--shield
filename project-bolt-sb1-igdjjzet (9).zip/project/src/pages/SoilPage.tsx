import { useState } from 'react';
import { Droplets, FlaskConical, Save, Trash2, Beaker, Sprout, AlertTriangle, Check } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, SoilReport } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const CROPS = ['Apple', 'Saffron', 'Rice', 'Walnut', 'Maize', 'Tomato'];
const SOIL_TYPES = ['clay', 'loam', 'sandy', 'silty'];

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

function npkStatus(value: number | null, low: number, high: number): { label: string; color: string } {
  if (value === null) return { label: '—', color: 'text-stone-400' };
  if (value < low) return { label: 'Low', color: 'text-red-600 bg-red-50' };
  if (value > high) return { label: 'High', color: 'text-amber-600 bg-amber-50' };
  return { label: 'Normal', color: 'text-emerald-600 bg-emerald-50' };
}

function generateAdvice(report: Partial<SoilReport>): { irrigation: string; nutrient: string } {
  const parts: string[] = [];
  const nParts: string[] = [];

  if (report.ph !== null && report.ph !== undefined) {
    if (report.ph < 6.0) parts.push('Soil is acidic — apply agricultural lime to raise pH. Most crops prefer pH 6.0-7.0.');
    else if (report.ph > 7.5) parts.push('Soil is alkaline — apply gypsum or sulfur to lower pH. Most crops prefer pH 6.0-7.0.');
    else parts.push('pH is in the optimal range for most crops.');
  }

  if (report.nitrogen !== null && report.nitrogen !== undefined && report.nitrogen < 280) {
    nParts.push('Nitrogen is low — apply urea or compost. Split application into 2-3 doses during the growing season.');
  } else if (report.nitrogen !== null && report.nitrogen !== undefined && report.nitrogen > 560) {
    nParts.push('Nitrogen is high — reduce fertilizer application to avoid excessive vegetative growth and disease susceptibility.');
  }

  if (report.phosphorus !== null && report.phosphorus !== undefined && report.phosphorus < 10) {
    nParts.push('Phosphorus is low — apply SSP or DAP at sowing time for better root development.');
  }

  if (report.potassium !== null && report.potassium !== undefined && report.potassium < 110) {
    nParts.push('Potassium is low — apply MOP (muriate of potash) to improve fruit quality and disease resistance.');
  }

  if (report.organic_carbon !== null && report.organic_carbon !== undefined && report.organic_carbon < 0.5) {
    nParts.push('Organic carbon is low — add farmyard manure, vermicompost or green manure to improve soil fertility.');
  }

  if (report.soil_type === 'sandy') parts.push('Sandy soil drains fast — use drip irrigation and mulch to retain moisture. Water more frequently in smaller amounts.');
  else if (report.soil_type === 'clay') parts.push('Clay soil retains water — avoid over-irrigation. Ensure proper drainage to prevent waterlogging.');
  else if (report.soil_type === 'loam') parts.push('Loamy soil is ideal — maintain balanced irrigation schedule based on crop needs.');

  return {
    irrigation: parts.join(' ') || 'Maintain regular irrigation based on crop and weather conditions.',
    nutrient: nParts.join(' ') || 'Nutrient levels are adequate. Continue regular soil testing every 2-3 years.',
  };
}

export function SoilPage() {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const sessionId = getSessionId();

  const [form, setForm] = useState({
    crop: 'Apple',
    ph: '',
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    organic_carbon: '',
    soil_type: 'loam',
    test_date: new Date().toISOString().split('T')[0],
  });

  const { data: reports, loading, error, reload } = useFetch<SoilReport[]>(async () => {
    const { data } = await supabase
      .from('soil_reports')
      .select('*')
      .eq('session_id', sessionId)
      .order('test_date', { ascending: false });
    return data ?? [];
  }, []);

  const submit = async () => {
    setSaving(true);
    const advice = generateAdvice({
      ph: form.ph ? Number(form.ph) : null,
      nitrogen: form.nitrogen ? Number(form.nitrogen) : null,
      phosphorus: form.phosphorus ? Number(form.phosphorus) : null,
      potassium: form.potassium ? Number(form.potassium) : null,
      organic_carbon: form.organic_carbon ? Number(form.organic_carbon) : null,
      soil_type: form.soil_type,
    });
    await supabase.from('soil_reports').insert({
      session_id: sessionId,
      crop: form.crop,
      ph: form.ph ? Number(form.ph) : null,
      nitrogen: form.nitrogen ? Number(form.nitrogen) : null,
      phosphorus: form.phosphorus ? Number(form.phosphorus) : null,
      potassium: form.potassium ? Number(form.potassium) : null,
      organic_carbon: form.organic_carbon ? Number(form.organic_carbon) : null,
      soil_type: form.soil_type,
      test_date: form.test_date,
      irrigation_advice: advice.irrigation,
      nutrient_advice: advice.nutrient,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
    setShowForm(false);
    setForm({ ...form, ph: '', nitrogen: '', phosphorus: '', potassium: '', organic_carbon: '' });
    reload();
  };

  const remove = async (id: string) => {
    await supabase.from('soil_reports').delete().eq('id', id);
    reload();
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner image={PHOTOS.farmerField} title={t('soil_title')} subtitle={t('soil_sub')} icon={<Droplets className="w-5 h-5" />} />

      {!showForm ? (
        <button onClick={() => setShowForm(true)} className="mb-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft">
          <FlaskConical className="w-4 h-4" /> {t('soil_add')}
        </button>
      ) : (
        <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 mb-6 animate-slide-up">
          <h3 className="font-bold text-stone-800 mb-4 flex items-center gap-2"><Beaker className="w-5 h-5 text-brand-600" /> {t('soil_add')}</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('soil_crop')}</label>
              <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('soil_date')}</label>
              <input type="date" value={form.test_date} onChange={(e) => setForm({ ...form, test_date: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('soil_type')}</label>
              <select value={form.soil_type} onChange={(e) => setForm({ ...form, soil_type: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {SOIL_TYPES.map((s) => <option key={s} value={s}>{t(`soil_type_${s}`)}</option>)}
              </select>
            </div>
            {[
              { key: 'ph', label: t('soil_ph') },
              { key: 'nitrogen', label: t('soil_n') },
              { key: 'phosphorus', label: t('soil_p') },
              { key: 'potassium', label: t('soil_k') },
              { key: 'organic_carbon', label: t('soil_oc') },
            ].map((f) => (
              <div key={f.key}>
                <label className="text-xs font-medium text-stone-500 mb-1 block">{f.label}</label>
                <input type="number" step="0.01" value={(form as any)[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
              </div>
            ))}
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors disabled:opacity-50">
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />} {saving ? '...' : saved ? 'Saved!' : t('soil_save')}
            </button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-sm font-medium hover:bg-stone-100">Cancel</button>
          </div>
        </div>
      )}

      {reports && reports.length === 0 ? (
        <EmptyState message={t('soil_empty')} />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {reports?.map((r) => (
            <div key={r.id} className="bg-white rounded-2xl border border-stone-100 p-5 shadow-soft group">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center"><Sprout className="w-5 h-5 text-brand-600" /></div>
                  <div>
                    <h3 className="font-bold text-stone-800 text-sm">{r.crop}</h3>
                    <p className="text-xs text-stone-400">{new Date(r.test_date).toLocaleDateString('en-IN')} · {r.soil_type}</p>
                  </div>
                </div>
                <button onClick={() => remove(r.id)} className="p-1.5 rounded-lg text-stone-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>

              <div className="grid grid-cols-5 gap-2 mb-3">
                {[
                  { label: 'pH', val: r.ph, s: npkStatus(r.ph, 6, 7.5) },
                  { label: 'N', val: r.nitrogen, s: npkStatus(r.nitrogen, 280, 560) },
                  { label: 'P', val: r.phosphorus, s: npkStatus(r.phosphorus, 10, 25) },
                  { label: 'K', val: r.potassium, s: npkStatus(r.potassium, 110, 280) },
                  { label: 'OC%', val: r.organic_carbon, s: npkStatus(r.organic_carbon, 0.5, 1.5) },
                ].map((m) => (
                  <div key={m.label} className="text-center rounded-lg bg-stone-50 py-2">
                    <div className="text-[10px] text-stone-400 font-medium">{m.label}</div>
                    <div className="text-sm font-bold text-stone-700">{m.val ?? '—'}</div>
                    {m.val !== null && m.val !== undefined && (
                      <div className={`text-[9px] px-1 rounded-full inline-block mt-0.5 font-medium ${m.s.color}`}>{m.s.label}</div>
                    )}
                  </div>
                ))}
              </div>

              {r.irrigation_advice && (
                <div className="rounded-xl bg-blue-50 border border-blue-100 p-3 mb-2">
                  <div className="text-xs font-bold text-blue-700 mb-1 flex items-center gap-1"><Droplets className="w-3 h-3" /> {t('soil_irrigation')}</div>
                  <p className="text-xs text-stone-700 leading-relaxed">{r.irrigation_advice}</p>
                </div>
              )}
              {r.nutrient_advice && (
                <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-3">
                  <div className="text-xs font-bold text-emerald-700 mb-1 flex items-center gap-1"><FlaskConical className="w-3 h-3" /> {t('soil_nutrient')}</div>
                  <p className="text-xs text-stone-700 leading-relaxed">{r.nutrient_advice}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Disclaimer text={t('disease_disclaimer')} />
    </div>
  );
}
