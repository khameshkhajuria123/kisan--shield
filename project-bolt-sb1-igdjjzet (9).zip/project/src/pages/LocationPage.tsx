import { useState, useRef, useEffect } from 'react';
import { MapPin, Crosshair, Loader2, Save, Trash2, Navigation, AlertCircle, Check } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, FarmerLocation, WeatherAlert } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

// J&K bounding box
const JK_BOUNDS = { minLat: 32.2, maxLat: 37.0, minLon: 73.5, maxLon: 78.0 };
const JK_CENTER = { lat: 34.15, lon: 75.5 };

function isInJK(lat: number, lon: number): boolean {
  return (
    lat >= JK_BOUNDS.minLat && lat <= JK_BOUNDS.maxLat &&
    lon >= JK_BOUNDS.minLon && lon <= JK_BOUNDS.maxLon
  );
}

// Approximate district detection from coordinates
const JK_DISTRICTS: { name: string; lat: number; lon: number }[] = [
  { name: 'Srinagar', lat: 34.08, lon: 74.8 },
  { name: 'Baramulla', lat: 34.2, lon: 74.36 },
  { name: 'Shopian', lat: 33.72, lon: 74.86 },
  { name: 'Anantnag', lat: 33.73, lon: 75.15 },
  { name: 'Pulwama', lat: 33.88, lon: 74.9 },
  { name: 'Kulgam', lat: 33.65, lon: 75.02 },
  { name: 'Budgam', lat: 34.03, lon: 74.83 },
  { name: 'Kupwara', lat: 34.53, lon: 74.26 },
  { name: 'Ganderbal', lat: 34.23, lon: 74.77 },
  { name: 'Bandipora', lat: 34.43, lon: 74.65 },
  { name: 'Jammu', lat: 32.73, lon: 74.86 },
  { name: 'Udhampur', lat: 32.92, lon: 75.15 },
  { name: 'Kathua', lat: 32.38, lon: 75.52 },
  { name: 'Doda', lat: 33.15, lon: 75.57 },
];

function nearestDistrict(lat: number, lon: number): string {
  let min = Infinity;
  let nearest = JK_DISTRICTS[0].name;
  for (const d of JK_DISTRICTS) {
    const dist = Math.hypot(d.lat - lat, d.lon - lon);
    if (dist < min) {
      min = dist;
      nearest = d.name;
    }
  }
  return nearest;
}

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

export function LocationPage() {
  const { t } = useLanguage();
  const [detecting, setDetecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPos, setCurrentPos] = useState<{ lat: number; lon: number; district: string | null } | null>(null);
  const [label, setLabel] = useState('');
  const [saveMsg, setSaveMsg] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const sessionId = getSessionId();

  const { data: savedLocs, loading, error: fetchError, reload } = useFetch<FarmerLocation[]>(async () => {
    const { data } = await supabase
      .from('farmer_locations')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: false });
    return data ?? [];
  }, []);

  // Also fetch weather alerts to show nearby ones
  const { data: alerts } = useFetch<WeatherAlert[]>(async () => {
    const { data } = await supabase
      .from('weather_alerts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);
    return data ?? [];
  }, []);

  const detect = () => {
    setDetecting(true);
    setError(null);
    if (!navigator.geolocation) {
      setError(t('location_error'));
      setDetecting(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        if (!isInJK(latitude, longitude)) {
          setError(t('location_outside_jk'));
          setDetecting(false);
          return;
        }
        const district = nearestDistrict(latitude, longitude);
        setCurrentPos({ lat: latitude, lon: longitude, district });
        setDetecting(false);
      },
      () => {
        setError(t('location_error'));
        setDetecting(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const saveLocation = async () => {
    if (!currentPos) return;
    await supabase.from('farmer_locations').insert({
      session_id: sessionId,
      label: label.trim() || null,
      latitude: currentPos.lat,
      longitude: currentPos.lon,
      district: currentPos.district,
    });
    setLabel('');
    setSaveMsg(true);
    setTimeout(() => setSaveMsg(false), 2500);
    reload();
  };

  const deleteLocation = async (id: string) => {
    await supabase.from('farmer_locations').delete().eq('id', id);
    reload();
  };

  // Build a simple visual map with positioned markers
  const mapWidth = 600;
  const mapHeight = 400;
  const projectX = (lon: number) => ((lon - JK_BOUNDS.minLon) / (JK_BOUNDS.maxLon - JK_BOUNDS.minLon)) * mapWidth;
  const projectY = (lat: number) => mapHeight - ((lat - JK_BOUNDS.minLat) / (JK_BOUNDS.maxLat - JK_BOUNDS.minLat)) * mapHeight;

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (fetchError) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.farmerField}
        title={t('location_title')}
        subtitle={t('location_sub')}
        icon={<MapPin className="w-5 h-5" />}
      />

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Map panel */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-5">
            {/* SVG-based map of J&K */}
            <div className="relative w-full overflow-hidden rounded-xl bg-gradient-to-br from-brand-50 to-teal-50 border border-brand-100" style={{ aspectRatio: '3 / 2' }}>
              <svg viewBox={`0 0 ${mapWidth} ${mapHeight}`} className="w-full h-full" ref={mapRef as any}>
                {/* J&K outline (simplified) */}
                <path
                  d="M 50 80 Q 80 50 150 60 Q 220 40 300 55 Q 380 45 450 70 Q 520 90 540 140 Q 530 200 500 240 Q 450 290 380 310 Q 300 330 220 315 Q 140 300 90 260 Q 50 220 40 160 Q 38 110 50 80 Z"
                  fill="rgba(34, 139, 34, 0.08)"
                  stroke="rgba(34, 139, 34, 0.3)"
                  strokeWidth="2"
                  strokeDasharray="5 3"
                />

                {/* District markers */}
                {JK_DISTRICTS.map((d) => (
                  <g key={d.name}>
                    <circle cx={projectX(d.lon)} cy={projectY(d.lat)} r="4" fill="rgba(34, 139, 34, 0.4)" />
                    <text
                      x={projectX(d.lon) + 7}
                      y={projectY(d.lat) + 3}
                      fill="rgba(68, 64, 60, 0.5)"
                      fontSize="9"
                      fontFamily="system-ui"
                    >
                      {d.name}
                    </text>
                  </g>
                ))}

                {/* Saved location markers */}
                {savedLocs?.map((loc) => (
                  <g key={loc.id}>
                    <circle cx={projectX(loc.longitude)} cy={projectY(loc.latitude)} r="6" fill="#22c55e" stroke="white" strokeWidth="2" />
                    <circle cx={projectX(loc.longitude)} cy={projectY(loc.latitude)} r="12" fill="none" stroke="#22c55e" strokeWidth="1" opacity="0.3">
                      <animate attributeName="r" values="6;14;6" dur="2s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.4;0;0.4" dur="2s" repeatCount="indefinite" />
                    </circle>
                  </g>
                ))}

                {/* Current detected position */}
                {currentPos && (
                  <g>
                    <circle cx={projectX(currentPos.lon)} cy={projectY(currentPos.lat)} r="8" fill="#ef4444" stroke="white" strokeWidth="2.5" />
                    <circle cx={projectX(currentPos.lon)} cy={projectY(currentPos.lat)} r="16" fill="none" stroke="#ef4444" strokeWidth="2" opacity="0.4">
                      <animate attributeName="r" values="8;20;8" dur="1.5s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.5;0;0.5" dur="1.5s" repeatCount="indefinite" />
                    </circle>
                    {currentPos.district && (
                      <text
                        x={projectX(currentPos.lon) + 12}
                        y={projectY(currentPos.lat) - 8}
                        fill="#dc2626"
                        fontSize="11"
                        fontWeight="bold"
                        fontFamily="system-ui"
                      >
                        {currentPos.district}
                      </text>
                    )}
                  </g>
                )}
              </svg>

              {/* Overlay legend */}
              <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur rounded-lg px-3 py-2 shadow-sm">
                <div className="flex items-center gap-2 text-xs text-stone-600">
                  <span className="w-2 h-2 rounded-full bg-red-500" /> GPS
                  <span className="w-2 h-2 rounded-full bg-green-500 ms-2" /> {t('location_saved')}
                </div>
              </div>
            </div>

            <p className="text-xs text-stone-400 mt-3 text-center">{t('location_map_hint')}</p>
          </div>

          {/* Nearby weather alerts */}
          {alerts && alerts.length > 0 && currentPos && (
            <div className="mt-4 bg-white rounded-2xl border border-stone-100 shadow-soft p-5">
              <h3 className="font-bold text-stone-800 text-sm mb-3 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                {t('weather_title')}
              </h3>
              <div className="space-y-2">
                {alerts.filter(a => !currentPos.district || a.district === currentPos.district || a.location === currentPos.district).length > 0 ? (
                  alerts
                    .filter(a => !currentPos.district || a.district === currentPos.district || a.location === currentPos.district)
                    .map((a) => (
                      <div key={a.id} className="rounded-xl bg-amber-50 border border-amber-100 p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-semibold text-stone-800">{a.alert_type}</span>
                          <span className="text-xs text-amber-600">{a.severity}</span>
                        </div>
                        <p className="text-xs text-stone-600">{a.description}</p>
                      </div>
                    ))
                ) : (
                  <p className="text-xs text-stone-500">{t('weather_none')}</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Side panel: GPS + saved locations */}
        <div className="lg:col-span-2 space-y-4">
          {/* GPS detection */}
          <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-5">
            <h3 className="font-bold text-stone-800 text-sm mb-4 flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-brand-600" />
              {t('location_detect')}
            </h3>

            <button
              onClick={detect}
              disabled={detecting}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors disabled:opacity-50 shadow-soft"
            >
              {detecting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Navigation className="w-5 h-5" />}
              {detecting ? t('location_detecting') : t('location_detect')}
            </button>

            {error && (
              <div className="mt-3 text-xs text-red-600 bg-red-50 rounded-lg px-3 py-2 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            {currentPos && (
              <div className="mt-4 space-y-3 animate-fade-in">
                <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-3">
                  <div className="flex items-center gap-2 text-emerald-700 mb-2">
                    <Check className="w-4 h-4" />
                    <span className="text-sm font-semibold">{t('location_district')}: {currentPos.district}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-stone-600">
                    <div>
                      <span className="text-stone-400">{t('location_lat')}</span>
                      <div className="font-mono font-medium">{currentPos.lat.toFixed(4)}</div>
                    </div>
                    <div>
                      <span className="text-stone-400">{t('location_lng')}</span>
                      <div className="font-mono font-medium">{currentPos.lon.toFixed(4)}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <input
                    type="text"
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                    placeholder={t('location_label')}
                    className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                  <button
                    onClick={saveLocation}
                    className="w-full mt-2 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-100 text-stone-700 text-sm font-medium hover:bg-stone-200 transition-colors"
                  >
                    {saveMsg ? <Check className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4" />}
                    {saveMsg ? 'Saved!' : t('location_save')}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Saved locations */}
          <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-5">
            <h3 className="font-bold text-stone-800 text-sm mb-3">{t('location_saved')}</h3>
            {savedLocs && savedLocs.length > 0 ? (
              <div className="space-y-2">
                {savedLocs.map((loc) => (
                  <div key={loc.id} className="flex items-center justify-between rounded-xl bg-stone-50 border border-stone-100 p-3 group">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                        <MapPin className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-stone-800">
                          {loc.label || loc.district || 'Farm'}
                        </div>
                        <div className="text-xs text-stone-400 font-mono">
                          {loc.latitude.toFixed(3)}, {loc.longitude.toFixed(3)}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => deleteLocation(loc.id)}
                      className="p-1.5 rounded-lg text-stone-300 hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState message={t('no_data')} />
            )}
          </div>
        </div>
      </div>

      <Disclaimer text={t('footer_disclaimer')} />
    </div>
  );
}
