import { useState, useMemo } from 'react';
import { ShieldAlert, CloudRain, Bug, Snowflake, Droplets, ThermometerSun, MapPin, Sprout } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, CropRisk } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const RISK_ICONS: Record<string, typeof ShieldAlert> = {
  Frost: Snowflake,
  Rain: CloudRain,
  Hailstorm: CloudRain,
  Snow: Snowflake,
  Wind: CloudRain,
  Flood: Droplets,
  Disease: Bug,
  Pest: Bug,
  Drought: ThermometerSun,
};

const LEVEL_STYLES: Record<string, string> = {
  severe: 'bg-red-50 text-red-700 border-red-200',
  high: 'bg-orange-50 text-orange-700 border-orange-200',
  moderate: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

const LEVEL_DOT: Record<string, string> = {
  severe: 'bg-red-500',
  high: 'bg-orange-500',
  moderate: 'bg-amber-500',
  low: 'bg-emerald-500',
};

export function RiskPage() {
  const { t } = useLanguage();
  const [cropFilter, setCropFilter] = useState('all');
  const [districtFilter, setDistrictFilter] = useState('all');

  const { data: risks, loading, error, reload } = useFetch<CropRisk[]>(async () => {
    const { data, error } = await supabase
      .from('crop_risk_predictions')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data ?? [];
  }, []);

  const crops = useMemo(() => {
    if (!risks) return [];
    return [...new Set(risks.map((r) => r.crop))].sort();
  }, [risks]);

  const districts = useMemo(() => {
    if (!risks) return [];
    return [...new Set(risks.map((r) => r.district).filter(Boolean))].sort() as string[];
  }, [risks]);

  const filtered = useMemo(() => {
    if (!risks) return [];
    return risks.filter(
      (r) =>
        (cropFilter === 'all' || r.crop === cropFilter) &&
        (districtFilter === 'all' || r.district === districtFilter)
    );
  }, [risks, cropFilter, districtFilter]);

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner
        image={PHOTOS.farmerField}
        title={t('risk_title')}
        subtitle={t('risk_sub')}
        icon={<ShieldAlert className="w-5 h-5" />}
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="flex items-center gap-2">
          <Sprout className="w-4 h-4 text-stone-400" />
          <select
            value={cropFilter}
            onChange={(e) => setCropFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-stone-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
          >
            <option value="all">{t('risk_all')}</option>
            {crops.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        {districts.length > 0 && (
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-stone-400" />
            <select
              value={districtFilter}
              onChange={(e) => setDistrictFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-stone-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="all">{t('weather_all')}</option>
              {districts.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Risk cards */}
      {filtered.length === 0 ? (
        <EmptyState message={t('risk_none')} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((risk) => {
            const Icon = RISK_ICONS[risk.risk_type] ?? ShieldAlert;
            const level = (risk.risk_level || 'moderate').toLowerCase();
            return (
              <div
                key={risk.id}
                className="bg-white rounded-2xl border border-stone-100 p-5 shadow-soft hover:shadow-card transition-all animate-slide-up"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-stone-50 flex items-center justify-center text-stone-600">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-stone-800 text-sm">{risk.crop}</h3>
                      <p className="text-xs text-stone-500">{risk.risk_type}</p>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border capitalize ${LEVEL_STYLES[level] ?? LEVEL_STYLES.moderate}`}>
                    <span className={`inline-block w-1.5 h-1.5 rounded-full ${LEVEL_DOT[level] ?? LEVEL_DOT.moderate} me-1.5`} />
                    {risk.risk_level}
                  </span>
                </div>

                {risk.district && (
                  <div className="flex items-center gap-1 text-xs text-stone-500 mb-2">
                    <MapPin className="w-3 h-3" />
                    {risk.district}
                  </div>
                )}

                {risk.growth_stage && (
                  <div className="text-xs text-brand-600 font-medium mb-2">
                    {t('risk_stage')}: {risk.growth_stage}
                  </div>
                )}

                <p className="text-sm text-stone-600 leading-relaxed mb-3">{risk.description}</p>

                {risk.recommendation && (
                  <div className="rounded-xl bg-brand-50/60 border border-brand-100 p-3">
                    <div className="text-xs font-bold text-brand-700 mb-1">{t('risk_reco')}</div>
                    <p className="text-xs text-stone-700 leading-relaxed">{risk.recommendation}</p>
                  </div>
                )}

                {risk.valid_to && (
                  <div className="text-[11px] text-stone-400 mt-3">
                    {t('risk_valid')}: {new Date(risk.valid_to).toLocaleDateString('en-IN')}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Disclaimer text={t('weather_sub')} />
    </div>
  );
}
