import { useState, useMemo } from 'react';
import { ClipboardList, Save, Trash2, TrendingUp, TrendingDown, Sprout, Plus, Check } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { supabase, FarmRecord } from '@/lib/supabase';
import { useFetch } from '@/lib/useFetch';
import { Loading, ErrorState, EmptyState, PageBanner, Disclaimer } from '@/components/ui';
import { PHOTOS } from '@/lib/photos';

const CROPS = ['Apple', 'Saffron', 'Rice', 'Walnut', 'Maize', 'Tomato'];
const UNITS = ['kanal', 'hectare', 'acre'];

function getSessionId(): string {
  let id = localStorage.getItem('kisan_session');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('kisan_session', id);
  }
  return id;
}

export function RecordsPage() {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const sessionId = getSessionId();

  const emptyForm = {
    season: `${new Date().getFullYear()} ${new Date().getMonth() >= 6 && new Date().getMonth() <= 10 ? 'Kharif' : 'Rabi'}`,
    crop: 'Apple',
    land_area: '',
    area_unit: 'kanal',
    seed_cost: '',
    fertilizer_cost: '',
    labor_cost: '',
    other_cost: '',
    production_kg: '',
    sold_kg: '',
    sale_price_per_kg: '',
    notes: '',
  };
  const [form, setForm] = useState(emptyForm);

  const { data: records, loading, error, reload } = useFetch<FarmRecord[]>(async () => {
    const { data } = await supabase
      .from('farm_records')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: false });
    return data ?? [];
  }, []);

  const summary = useMemo(() => {
    if (!records || records.length === 0) return null;
    const totalCost = records.reduce((s, r) => s + (r.seed_cost ?? 0) + (r.fertilizer_cost ?? 0) + (r.labor_cost ?? 0) + (r.other_cost ?? 0), 0);
    const totalRevenue = records.reduce((s, r) => s + ((r.sold_kg ?? 0) * (r.sale_price_per_kg ?? 0)), 0);
    return { totalCost, totalRevenue, profit: totalRevenue - totalCost, count: records.length };
  }, [records]);

  const submit = async () => {
    setSaving(true);
    await supabase.from('farm_records').insert({
      session_id: sessionId,
      season: form.season,
      crop: form.crop,
      land_area: form.land_area ? Number(form.land_area) : null,
      area_unit: form.area_unit,
      seed_cost: form.seed_cost ? Number(form.seed_cost) : 0,
      fertilizer_cost: form.fertilizer_cost ? Number(form.fertilizer_cost) : 0,
      labor_cost: form.labor_cost ? Number(form.labor_cost) : 0,
      other_cost: form.other_cost ? Number(form.other_cost) : 0,
      production_kg: form.production_kg ? Number(form.production_kg) : null,
      sold_kg: form.sold_kg ? Number(form.sold_kg) : null,
      sale_price_per_kg: form.sale_price_per_kg ? Number(form.sale_price_per_kg) : null,
      notes: form.notes || null,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
    setShowForm(false);
    setForm(emptyForm);
    reload();
  };

  const remove = async (id: string) => {
    await supabase.from('farm_records').delete().eq('id', id);
    reload();
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><Loading /></div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8"><ErrorState onRetry={reload} /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageBanner image={PHOTOS.farmerOxen} title={t('records_title')} subtitle={t('records_sub')} icon={<ClipboardList className="w-5 h-5" />} />

      {/* Summary cards */}
      {summary && (
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white rounded-2xl border border-stone-100 p-4 shadow-soft">
            <div className="text-xs text-stone-500 font-medium mb-1">{t('records_total_cost')}</div>
            <div className="text-xl font-bold text-stone-800">₹{summary.totalCost.toLocaleString('en-IN')}</div>
          </div>
          <div className="bg-white rounded-2xl border border-stone-100 p-4 shadow-soft">
            <div className="text-xs text-stone-500 font-medium mb-1">{t('records_revenue')}</div>
            <div className="text-xl font-bold text-stone-800">₹{summary.totalRevenue.toLocaleString('en-IN')}</div>
          </div>
          <div className={`bg-white rounded-2xl border border-stone-100 p-4 shadow-soft ${summary.profit >= 0 ? '' : ''}`}>
            <div className="text-xs text-stone-500 font-medium mb-1">{t('records_profit')}</div>
            <div className={`text-xl font-bold flex items-center gap-1.5 ${summary.profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {summary.profit >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              ₹{Math.abs(summary.profit).toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      )}

      {!showForm ? (
        <button onClick={() => setShowForm(true)} className="mb-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-soft">
          <Plus className="w-4 h-4" /> {t('records_add')}
        </button>
      ) : (
        <div className="bg-white rounded-2xl border border-stone-100 shadow-soft p-6 mb-6 animate-slide-up">
          <h3 className="font-bold text-stone-800 mb-4">{t('records_add')}</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('records_season')}</label>
              <input type="text" value={form.season} onChange={(e) => setForm({ ...form, season: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('records_crop')}</label>
              <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                {CROPS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('records_area')}</label>
              <input type="number" value={form.land_area} onChange={(e) => setForm({ ...form, land_area: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <div>
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('records_unit')}</label>
              <select value={form.area_unit} onChange={(e) => setForm({ ...form, area_unit: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 capitalize">
                {UNITS.map((u) => <option key={u} value={u} className="capitalize">{t(`unit_${u}`)}</option>)}
              </select>
            </div>
            {[
              { key: 'seed_cost', label: t('records_seed_cost') },
              { key: 'fertilizer_cost', label: t('records_fert_cost') },
              { key: 'labor_cost', label: t('records_labor_cost') },
              { key: 'other_cost', label: t('records_other_cost') },
              { key: 'production_kg', label: t('records_production') },
              { key: 'sold_kg', label: t('records_sold') },
              { key: 'sale_price_per_kg', label: t('records_sale_price') },
            ].map((f) => (
              <div key={f.key}>
                <label className="text-xs font-medium text-stone-500 mb-1 block">{f.label}</label>
                <input type="number" value={(form as any)[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
              </div>
            ))}
            <div className="sm:col-span-2 lg:col-span-4">
              <label className="text-xs font-medium text-stone-500 mb-1 block">{t('records_notes')}</label>
              <input type="text" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="—" className="w-full px-3 py-2 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-50">
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />} {saving ? '...' : saved ? 'Saved!' : t('records_save')}
            </button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-sm font-medium hover:bg-stone-100">Cancel</button>
          </div>
        </div>
      )}

      {records && records.length === 0 ? (
        <EmptyState message={t('records_empty')} />
      ) : (
        <div className="bg-white rounded-2xl border border-stone-100 shadow-soft overflow-hidden overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-stone-100 bg-stone-50/50">
                <th className="text-start px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_season')}</th>
                <th className="text-start px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_crop')}</th>
                <th className="text-end px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_total_cost')}</th>
                <th className="text-end px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_production')}</th>
                <th className="text-end px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_revenue')}</th>
                <th className="text-end px-4 py-3 font-semibold text-stone-600 text-xs uppercase tracking-wide">{t('records_profit')}</th>
                <th className="px-2 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {records?.map((r) => {
                const cost = (r.seed_cost ?? 0) + (r.fertilizer_cost ?? 0) + (r.labor_cost ?? 0) + (r.other_cost ?? 0);
                const revenue = (r.sold_kg ?? 0) * (r.sale_price_per_kg ?? 0);
                const profit = revenue - cost;
                return (
                  <tr key={r.id} className="border-b border-stone-50 hover:bg-stone-50/30 group">
                    <td className="px-4 py-3 font-medium text-stone-700">{r.season}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5">
                        <Sprout className="w-3.5 h-3.5 text-brand-500" />
                        {r.crop}
                      </span>
                    </td>
                    <td className="text-end px-4 py-3 text-stone-600">₹{cost.toLocaleString('en-IN')}</td>
                    <td className="text-end px-4 py-3 text-stone-600">{r.production_kg ? `${r.production_kg} kg` : '—'}</td>
                    <td className="text-end px-4 py-3 text-stone-600">₹{revenue.toLocaleString('en-IN')}</td>
                    <td className={`text-end px-4 py-3 font-semibold ${profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      {profit >= 0 ? '+' : ''}₹{profit.toLocaleString('en-IN')}
                    </td>
                    <td className="px-2 py-3">
                      <button onClick={() => remove(r.id)} className="p-1.5 rounded-lg text-stone-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Disclaimer text={t('profit_disclaimer')} />
    </div>
  );
}
