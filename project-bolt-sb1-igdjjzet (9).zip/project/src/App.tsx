import { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from '@/i18n/LanguageContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Page } from '@/lib/types';
import { HomePage } from '@/pages/HomePage';
import { WeatherPage } from '@/pages/WeatherPage';
import { CalendarPage } from '@/pages/CalendarPage';
import { MarketPage } from '@/pages/MarketPage';
import { SchemesPage } from '@/pages/SchemesPage';
import { DiseasePage } from '@/pages/DiseasePage';
import { ProfitPage } from '@/pages/ProfitPage';
import { AssistantPage } from '@/pages/AssistantPage';
import { RiskPage } from '@/pages/RiskPage';
import { LocationPage } from '@/pages/LocationPage';
import { SoilPage } from '@/pages/SoilPage';
import { RecordsPage } from '@/pages/RecordsPage';
import { MarketplacePage } from '@/pages/MarketplacePage';
import { PassportPage } from '@/pages/PassportPage';

function AppInner() {
  const [page, setPage] = useState<Page>('home');

  const navigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to top on page change (instant for hash)
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      <Header current={page} onNavigate={navigate} />
      <main className="flex-1">
        {page === 'home' && <HomePage onNavigate={navigate} />}
        {page === 'weather' && <WeatherPage />}
        {page === 'calendar' && <CalendarPage />}
        {page === 'market' && <MarketPage />}
        {page === 'schemes' && <SchemesPage />}
        {page === 'disease' && <DiseasePage />}
        {page === 'profit' && <ProfitPage />}
        {page === 'assistant' && <AssistantPage />}
        {page === 'risk' && <RiskPage />}
        {page === 'location' && <LocationPage />}
        {page === 'soil' && <SoilPage />}
        {page === 'records' && <RecordsPage />}
        {page === 'marketplace' && <MarketplacePage />}
        {page === 'passport' && <PassportPage />}
      </main>
      <Footer onNavigate={navigate} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppInner />
    </LanguageProvider>
  );
}
