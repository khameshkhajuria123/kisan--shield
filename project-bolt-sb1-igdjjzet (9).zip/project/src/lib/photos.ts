// Real stock photos from Pexels (license-free, guaranteed to load)

export const PHOTOS = {
  // Hero — apple harvest in India
  heroApple: 'https://images.pexels.com/photos/3019836/pexels-photo-3019836.jpeg?auto=compress&cs=tinysrgb&w=1600',
  heroApple2: 'https://images.pexels.com/photos/40233646/pexels-photo-40233646.jpeg?auto=compress&cs=tinysrgb&w=1600',

  // Farmer portraits
  farmerPortrait1: 'https://images.pexels.com/photos/32277759/pexels-photo-32277759.jpeg?auto=compress&cs=tinysrgb&w=940',
  farmerPortrait2: 'https://images.pexels.com/photos/9268303/pexels-photo-9268303.jpeg?auto=compress&cs=tinysrgb&w=940',
  farmerPortrait3: 'https://images.pexels.com/photos/37447582/pexels-photo-37447582.jpeg?auto=compress&cs=tinysrgb&w=940',

  // Crop photos for feature cards & calendar
  apple: 'https://images.pexels.com/photos/40233656/pexels-photo-40233656.jpeg?auto=compress&cs=tinysrgb&w=940',
  appleHarvest: 'https://images.pexels.com/photos/40233646/pexels-photo-40233646.jpeg?auto=compress&cs=tinysrgb&w=940',
  appleTree: 'https://images.pexels.com/photos/40233653/pexels-photo-40233653.jpeg?auto=compress&cs=tinysrgb&w=940',

  saffron: 'https://images.pexels.com/photos/14262714/pexels-photo-14262714.jpeg?auto=compress&cs=tinysrgb&w=940',
  saffronField: 'https://images.pexels.com/photos/34060258/pexels-photo-34060258.jpeg?auto=compress&cs=tinysrgb&w=940',
  saffronClose: 'https://images.pexels.com/photos/34060195/pexels-photo-34060195.jpeg?auto=compress&cs=tinysrgb&w=940',

  rice: 'https://images.pexels.com/photos/14025944/pexels-photo-14025944.jpeg?auto=compress&cs=tinysrgb&w=940',
  riceTerrace: 'https://images.pexels.com/photos/14035884/pexels-photo-14035884.jpeg?auto=compress&cs=tinysrgb&w=940',
  riceHarvest: 'https://images.pexels.com/photos/11070641/pexels-photo-11070641.jpeg?auto=compress&cs=tinysrgb&w=940',
  ricePlant: 'https://images.pexels.com/photos/20269183/pexels-photo-20269183.jpeg?auto=compress&cs=tinysrgb&w=940',

  walnut: 'https://images.pexels.com/photos/5753023/pexels-photo-5753023.jpeg?auto=compress&cs=tinysrgb&w=940',

  // General farming
  farmerField: 'https://images.pexels.com/photos/11688197/pexels-photo-11688197.jpeg?auto=compress&cs=tinysrgb&w=940',
  farmerOxen: 'https://images.pexels.com/photos/37013053/pexels-photo-37013053.jpeg?auto=compress&cs=tinysrgb&w=940',
  womenHarvest: 'https://images.pexels.com/photos/2382904/pexels-photo-2382904.jpeg?auto=compress&cs=tinysrgb&w=940',

  // CTA banner
  ctaBanner: 'https://images.pexels.com/photos/40233642/pexels-photo-40233642.jpeg?auto=compress&cs=tinysrgb&w=1600',
};

// Crop → photo mapping
export const CROP_PHOTO: Record<string, string> = {
  Apple: PHOTOS.appleHarvest,
  Saffron: PHOTOS.saffronField,
  Rice: PHOTOS.riceTerrace,
  Walnut: PHOTOS.walnut,
  Maize: PHOTOS.farmerField,
  Tomato: PHOTOS.farmerField,
};
