import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!url || !anonKey) {
  throw new Error('Missing Supabase env vars. Check .env for VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.');
}

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: false },
});

export type CropCalendar = {
  id: string;
  crop: string;
  month: number;
  operation: string;
  detail: string | null;
  icon: string | null;
};

export type MarketPrice = {
  id: string;
  crop: string;
  variety: string | null;
  grade: string | null;
  mandi: string;
  district: string | null;
  price_per_kg: number;
  unit: string;
  price_date: string;
  source: string | null;
};

export type GovtScheme = {
  id: string;
  name: string;
  category: string | null;
  agency: string | null;
  eligibility: string | null;
  benefits: string | null;
  documents: string | null;
  deadline: string | null;
  application_url: string | null;
};

export type WeatherAlert = {
  id: string;
  location: string;
  district: string | null;
  alert_type: string;
  severity: string | null;
  description: string | null;
  valid_from: string | null;
  valid_to: string | null;
  recommendation: string | null;
};

export type DiseaseEntry = {
  id: string;
  crop: string;
  disease_name: string;
  type: string | null;
  symptoms: string | null;
  treatment: string | null;
  prevention: string | null;
  severity: string | null;
};

export type ProfitRecord = {
  id: string;
  crop: string;
  land_area: number | null;
  area_unit: string | null;
  expected_yield_kg: number | null;
  selling_price_per_kg: number | null;
  total_cost: number | null;
  created_at: string;
};

export type ChatMessage = {
  id: string;
  session_id: string;
  question: string;
  answer: string;
  lang: string;
  crop: string | null;
  created_at: string;
};

export type CropRisk = {
  id: string;
  crop: string;
  district: string | null;
  risk_type: string;
  risk_level: string;
  growth_stage: string | null;
  description: string | null;
  recommendation: string | null;
  valid_from: string;
  valid_to: string | null;
};

export type FarmerLocation = {
  id: string;
  session_id: string;
  label: string | null;
  latitude: number;
  longitude: number;
  district: string | null;
  created_at: string;
};

export type SoilReport = {
  id: string;
  session_id: string;
  crop: string;
  ph: number | null;
  nitrogen: number | null;
  phosphorus: number | null;
  potassium: number | null;
  organic_carbon: number | null;
  soil_type: string | null;
  irrigation_advice: string | null;
  nutrient_advice: string | null;
  test_date: string;
  created_at: string;
};

export type FarmRecord = {
  id: string;
  session_id: string;
  season: string;
  crop: string;
  land_area: number | null;
  area_unit: string | null;
  seed_cost: number | null;
  fertilizer_cost: number | null;
  labor_cost: number | null;
  other_cost: number | null;
  production_kg: number | null;
  sold_kg: number | null;
  sale_price_per_kg: number | null;
  notes: string | null;
  created_at: string;
};

export type MarketplaceListing = {
  id: string;
  session_id: string;
  crop: string;
  variety: string | null;
  quantity_kg: number;
  grade: string | null;
  price_per_kg: number;
  district: string | null;
  contact_name: string | null;
  contact_phone: string | null;
  status: string;
  notes: string | null;
  created_at: string;
};

export type CropPassport = {
  id: string;
  session_id: string;
  batch_id: string;
  crop: string;
  variety: string | null;
  farm_name: string | null;
  district: string | null;
  harvest_date: string;
  quantity_kg: number | null;
  grade: string | null;
  storage_type: string | null;
  storage_date: string | null;
  certifications: string | null;
  quality_notes: string | null;
  qr_code: string | null;
  status: string;
  created_at: string;
};
