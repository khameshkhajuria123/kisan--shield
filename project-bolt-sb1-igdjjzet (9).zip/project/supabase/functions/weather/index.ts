import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

// Major J&K locations with approximate lat/lon
const LOCATIONS: { name: string; district: string; lat: number; lon: number }[] = [
  { name: 'Srinagar', district: 'Srinagar', lat: 34.08, lon: 74.8 },
  { name: 'Shopian', district: 'Shopian', lat: 33.72, lon: 74.86 },
  { name: 'Baramulla', district: 'Baramulla', lat: 34.2, lon: 74.36 },
  { name: 'Anantnag', district: 'Anantnag', lat: 33.73, lon: 75.15 },
  { name: 'Pulwama', district: 'Pulwama', lat: 33.88, lon: 74.9 },
  { name: 'Kulgam', district: 'Kulgam', lat: 33.65, lon: 75.02 },
  { name: 'Budgam', district: 'Budgam', lat: 34.03, lon: 74.83 },
  { name: 'Kupwara', district: 'Kupwara', lat: 34.53, lon: 74.26 },
  { name: 'Ganderbal', district: 'Ganderbal', lat: 34.23, lon: 74.77 },
  { name: 'Bandipora', district: 'Bandipora', lat: 34.43, lon: 74.65 },
  { name: 'Jammu', district: 'Jammu', lat: 32.73, lon: 74.86 },
  { name: 'Udhampur', district: 'Udhampur', lat: 32.92, lon: 75.15 },
  { name: 'Kathua', district: 'Kathua', lat: 32.38, lon: 75.52 },
  { name: 'Doda', district: 'Doda', lat: 33.15, lon: 75.57 },
];

type OpenMeteoResponse = {
  current?: {
    temperature_2m: number;
    weather_code: number;
    wind_speed_10m: number;
    precipitation: number;
  };
  daily?: {
    temperature_2m_min: number[];
    temperature_2m_max: number[];
    precipitation_sum: number[];
    precipitation_probability_max: number[];
    snowfall_sum: number[];
    wind_speed_10m_max: number[];
    weather_code: number[];
    time: string[];
  };
};

function buildAlert(loc: (typeof LOCATIONS)[number], wx: OpenMeteoResponse) {
  const alerts: {
    location: string;
    district: string;
    alert_type: string;
    severity: string;
    description: string;
    recommendation: string;
  }[] = [];

  const daily = wx.daily;
  if (!daily) return alerts;

  for (let i = 0; i < Math.min(3, daily.time.length); i++) {
    const tMin = daily.temperature_2m_min[i];
    const tMax = daily.temperature_2m_max[i];
    const precip = daily.precipitation_sum[i];
    const precipProb = daily.precipitation_probability_max[i];
    const snow = daily.snowfall_sum[i];
    const wind = daily.wind_speed_10m_max[i];
    const code = daily.weather_code[i];

    // Frost alert
    if (tMin <= 0) {
      const sev = tMin <= -4 ? 'Severe' : tMin <= -1 ? 'Moderate' : 'Light';
      alerts.push({
        location: loc.name,
        district: loc.district,
        alert_type: 'Frost',
        severity: sev,
        description: `Minimum temperature ${tMin}°C on ${daily.time[i]}. Risk of frost damage to sensitive crops and young plants.`,
        recommendation:
          'Cover nursery beds and young plants with polythene or straw. Delay irrigation until midday. Protect saffron corms with mulch.',
      });
    }

    // Snow alert
    if (snow > 0.5) {
      const sev = snow > 5 ? 'Severe' : snow > 2 ? 'Moderate' : 'Light';
      alerts.push({
        location: loc.name,
        district: loc.district,
        alert_type: 'Snow',
        severity: sev,
        description: `${snow} cm snowfall expected on ${daily.time[i]}.`,
        recommendation:
          'Support young apple trees with stakes to prevent branch breakage. Move harvested produce to safe storage. Avoid orchard ladder work.',
      });
    }

    // Heavy rain
    if (precip > 10) {
      alerts.push({
        location: loc.name,
        district: loc.district,
        alert_type: 'Rain',
        severity: precip > 25 ? 'Severe' : 'Moderate',
        description: `${precip} mm rainfall with ${precipProb}% probability on ${daily.time[i]}.`,
        recommendation:
          'Delay pesticide and fertilizer sprays. Clear drainage channels in orchards and rice fields. Check for waterlogging in saffron beds.',
      });
    }

    // Hailstorm watch (weather code 95-99 = thunderstorm with hail)
    if (code >= 95) {
      alerts.push({
        location: loc.name,
        district: loc.district,
        alert_type: 'Hailstorm',
        severity: 'Watch',
        description: `Thunderstorm with possible hail on ${daily.time[i]} (weather code ${code}).`,
        recommendation:
          'Keep anti-hail nets ready and deployed in apple orchards. Stay alert to updated forecasts. Postpone harvest if possible.',
      });
    }

    // Strong wind
    if (wind > 40) {
      alerts.push({
        location: loc.name,
        district: loc.district,
        alert_type: 'Wind',
        severity: wind > 60 ? 'Severe' : 'Moderate',
        description: `Wind gusts up to ${wind} km/h on ${daily.time[i]}.`,
        recommendation:
          'Secure loosely tied plants and orchard props. Delay ladder-based orchard work. Check for fallen branches after the event.',
      });
    }
  }

  return alerts;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const allAlerts: ReturnType<typeof buildAlert> = [];

    for (const loc of LOCATIONS) {
      const url =
        `https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}` +
        `&current=temperature_2m,weather_code,wind_speed_10m,precipitation` +
        `&daily=temperature_2m_min,temperature_2m_max,precipitation_sum,precipitation_probability_max,snowfall_sum,wind_speed_10m_max,weather_code` +
        `&forecast_days=3&timezone=Asia/Kolkata`;

      const res = await fetch(url);
      if (!res.ok) continue;
      const wx: OpenMeteoResponse = await res.json();
      allAlerts.push(...buildAlert(loc, wx));
    }

    // Replace cached alerts: clear old, insert new
    await supabase.from('weather_alerts').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (allAlerts.length > 0) {
      const now = new Date();
      const validFrom = now.toISOString();
      const validTo = new Date(now.getTime() + 72 * 3600 * 1000).toISOString();
      const rows = allAlerts.map((a) => ({ ...a, valid_from: validFrom, valid_to: validTo }));
      await supabase.from('weather_alerts').insert(rows);
    }

    return new Response(
      JSON.stringify({ ok: true, count: allAlerts.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
