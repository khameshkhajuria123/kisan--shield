import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

type ChatRequest = {
  question: string;
  lang: string;
  crop?: string;
  session_id: string;
};

// Crop keyword mapping for fuzzy matching
const CROP_KEYWORDS: Record<string, string[]> = {
  Apple: ['apple', 'seb', 'safar', 'سیب', 'सेब', 'safarchand'],
  Saffron: ['saffron', 'kesar', 'zafran', 'زعفران', 'केसर', 'kong'],
  Rice: ['rice', 'paddy', 'chawal', 'chaval', 'چاول', 'चावल', 'dhan', 'dhaan'],
  Walnut: ['walnut', 'akhrot', 'akrot', 'اخروٹ', 'अखरोट'],
  Maize: ['maize', 'corn', 'makka', 'makki', 'مکئی', 'मक्का', 'bhutta'],
  Tomato: ['tomato', 'tamatar', 'ٹماٹر', 'टमाटर'],
};

// Topic keyword mapping
const TOPIC_KEYWORDS: Record<string, string[]> = {
  disease: ['disease', 'daag', 'spot', 'leaf', 'rot', 'blight', 'pest', 'insect', 'fungus', 'mold', 'mould', 'yellow', 'wilt', 'bug', 'रोग', 'बीमारी', 'दाग', 'بیماری', 'کیڑا', ' fungus'],
  weather: ['weather', 'frost', 'rain', 'snow', 'hail', 'wind', 'temperature', 'cold', 'mausam', 'मौसम', 'ठंड', 'بارش', 'موسم', 'برف'],
  market: ['price', 'rate', 'mandi', 'market', 'sell', 'selling', 'bhaav', 'भाव', 'दाम', 'منڈی', 'بھاؤ', 'market'],
  scheme: ['scheme', 'subsidy', 'government', 'govt', 'pmkisan', 'kisan', 'loan', 'insurance', 'yojana', 'योजना', 'सब्सिडी', 'اسکیم', 'حکومت'],
  calendar: ['when', 'sow', 'plant', 'harvest', 'prune', 'fertilize', 'irrigate', 'month', 'season', 'kab', 'कब', 'बोना', 'कटाई', 'kis mahine'],
  profit: ['profit', 'cost', 'income', 'revenue', 'expense', 'munafa', 'laagat', 'मुनाफा', 'लागत', 'منافع', 'لاگت'],
};

function detectCrop(question: string): string | null {
  const q = question.toLowerCase();
  for (const [crop, keywords] of Object.entries(CROP_KEYWORDS)) {
    if (keywords.some((k) => q.includes(k))) return crop;
  }
  return null;
}

function detectTopic(question: string): string {
  const q = question.toLowerCase();
  let best = 'general';
  let bestScore = 0;
  for (const [topic, keywords] of Object.entries(TOPIC_KEYWORDS)) {
    const score = keywords.filter((k) => q.includes(k)).length;
    if (score > bestScore) {
      bestScore = score;
      best = topic;
    }
  }
  return best;
}

async function generateAnswer(
  question: string,
  lang: string,
  crop: string | null,
  topic: string,
  supabase: ReturnType<typeof createClient>
): Promise<{ answer: string; matchedCrop: string | null }> {
  const detectedCrop = crop ?? detectCrop(question);
  const parts: string[] = [];

  // Build answer based on topic
  if (topic === 'disease' && detectedCrop) {
    const { data: diseases } = await supabase
      .from('disease_library')
      .select('*')
      .ilike('crop', detectedCrop)
      .limit(3);

    if (diseases && diseases.length > 0) {
      parts.push(`For ${detectedCrop}, here are common diseases to watch for:`);
      for (const d of diseases) {
        parts.push(
          `\n\n**${d.disease_name}** (${d.severity ?? 'Unknown'} severity)\n` +
          `Symptoms: ${d.symptoms ?? 'N/A'}\n` +
          `Treatment: ${d.treatment ?? 'N/A'}\n` +
          `Prevention: ${d.prevention ?? 'N/A'}`
        );
      }
      parts.push('\n\nFor accurate diagnosis, upload a photo on the Disease Detector page or consult your nearest Krishi Vigyan Kendra.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  if (topic === 'weather') {
    const { data: alerts } = await supabase
      .from('weather_alerts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);

    if (alerts && alerts.length > 0) {
      parts.push('Here are the latest weather alerts for Jammu & Kashmir:');
      for (const a of alerts) {
        parts.push(
          `\n\n**${a.alert_type} — ${a.severity ?? 'Watch'}** (${a.location}${a.district ? ', ' + a.district : ''})\n` +
          `${a.description ?? ''}\n` +
          `Recommendation: ${a.recommendation ?? 'Stay alert to changing conditions.'}`
        );
      }
      parts.push('\n\nCheck the Weather Alerts page for the full list and use the GPS map to see alerts near your location.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
    parts.push('No active weather alerts right now. Check the Weather Alerts page regularly, especially during frost season (March-April) and monsoon months (July-September).');
    return { answer: parts.join(''), matchedCrop: detectedCrop };
  }

  if (topic === 'market' && detectedCrop) {
    const { data: prices } = await supabase
      .from('market_prices')
      .select('*')
      .ilike('crop', detectedCrop)
      .order('price_date', { ascending: false })
      .limit(5);

    if (prices && prices.length > 0) {
      parts.push(`Latest mandi prices for ${detectedCrop}:`);
      for (const p of prices) {
        parts.push(
          `\n• ${p.mandi}${p.district ? ', ' + p.district : ''}: ₹${p.price_per_kg}/${p.unit}` +
          `${p.grade ? ` (${p.grade} grade)` : ''} — ${new Date(p.price_date).toLocaleDateString('en-IN')}`
        );
      }
      parts.push('\n\nAlways confirm with your local mandi before selling. Prices vary by grade, variety and location.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  if (topic === 'market') {
    const { data: prices } = await supabase
      .from('market_prices')
      .select('*')
      .order('price_date', { ascending: false })
      .limit(8);

    if (prices && prices.length > 0) {
      parts.push('Here are the latest mandi prices across J&K:');
      for (const p of prices) {
        parts.push(`\n• ${p.crop}: ₹${p.price_per_kg}/${p.unit} at ${p.mandi}${p.district ? ', ' + p.district : ''}`);
      }
      parts.push('\n\nVisit the Market Prices page for more details and filtering by crop.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  if (topic === 'scheme') {
    const { data: schemes } = await supabase
      .from('govt_schemes')
      .select('*')
      .order('name')
      .limit(4);

    if (schemes && schemes.length > 0) {
      parts.push('Here are some government schemes available for J&K farmers:');
      for (const s of schemes) {
        parts.push(
          `\n\n**${s.name}**${s.category ? ` (${s.category})` : ''}\n` +
          `Benefits: ${s.benefits ?? 'N/A'}\n` +
          `Eligibility: ${s.eligibility ?? 'N/A'}\n` +
          `${s.deadline ? `Deadline: ${s.deadline}\n` : ''}` +
          `${s.application_url ? `Apply: ${s.application_url}` : ''}`
        );
      }
      parts.push('\n\nVisit the Govt Schemes page for the complete list with documents and deadlines.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  if ((topic === 'calendar' || topic === 'general') && detectedCrop) {
    const currentMonth = new Date().getMonth() + 1;
    const { data: calendar } = await supabase
      .from('crop_calendar')
      .select('*')
      .ilike('crop', detectedCrop)
      .eq('month', currentMonth)
      .limit(5);

    if (calendar && calendar.length > 0) {
      const monthName = new Date(2000, currentMonth - 1).toLocaleString('en-US', { month: 'long' });
      parts.push(`For ${detectedCrop} in ${monthName}, here are the recommended operations:`);
      for (const c of calendar) {
        parts.push(`\n• ${c.operation}${c.detail ? ` — ${c.detail}` : ''}`);
      }
      parts.push('\n\nCheck the Crop Calendar page for the full month-by-month guide.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }

    // If no data for current month, get general calendar
    const { data: allCal } = await supabase
      .from('crop_calendar')
      .select('*')
      .ilike('crop', detectedCrop)
      .order('month')
      .limit(6);

    if (allCal && allCal.length > 0) {
      parts.push(`Here is the annual calendar for ${detectedCrop}:`);
      for (const c of allCal) {
        const mName = new Date(2000, c.month - 1).toLocaleString('en-US', { month: 'short' });
        parts.push(`\n• ${mName}: ${c.operation}`);
      }
      parts.push('\n\nVisit the Crop Calendar page for detailed month-by-month guidance.');
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  if (topic === 'profit' && detectedCrop) {
    const { data: prices } = await supabase
      .from('market_prices')
      .select('*')
      .ilike('crop', detectedCrop)
      .order('price_date', { ascending: false })
      .limit(1);

    const latestPrice = prices?.[0];
    if (latestPrice) {
      parts.push(
        `For ${detectedCrop}, the latest mandi price is ₹${latestPrice.price_per_kg}/${latestPrice.unit} at ${latestPrice.mandi}.\n\n` +
        `To estimate your profit:\n` +
        `1. Enter your expected harvest (kg)\n` +
        `2. Enter the selling price (₹/kg) — you can use ₹${latestPrice.price_per_kg} as a reference\n` +
        `3. Enter your total farming costs (seeds, fertilizer, labor, transport, etc.)\n\n` +
        `Visit the Profit Calculator page to calculate your expected revenue and net profit.`
      );
      return { answer: parts.join(''), matchedCrop: detectedCrop };
    }
  }

  // Fallback: general guidance
  if (detectedCrop) {
    parts.push(
      `You asked about ${detectedCrop}. I can help you with:\n\n` +
      `• Disease identification and treatment\n` +
      `• Monthly farming operations (calendar)\n` +
      `• Latest mandi prices\n` +
      `• Government schemes and subsidies\n` +
      `• Profit estimation\n\n` +
      `Try asking: "What diseases affect ${detectedCrop}?" or "When should I prune ${detectedCrop}?" or "What is the price of ${detectedCrop}?"`
    );
  } else {
    parts.push(
      `I'm your KisanShield AI farming assistant for Jammu & Kashmir. I can help you with:\n\n` +
      `• Crop disease identification and treatment (apple, saffron, rice, walnut, maize, tomato)\n` +
      `• Monthly farming operations and crop calendar\n` +
      `• Latest mandi prices across J&K\n` +
      `• Government schemes and subsidies\n` +
      `• Weather alerts and crop risk predictions\n` +
      `• Profit calculation for your farm\n\n` +
      `Try asking: "What diseases affect apple trees?" or "When should I harvest saffron?" or "What are the latest weather alerts?"`
    );
  }

  return { answer: parts.join(''), matchedCrop: detectedCrop };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: ChatRequest = await req.json();
    const { question, lang, crop, session_id } = body;

    if (!question || !question.trim()) {
      return new Response(
        JSON.stringify({ error: 'Question is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const topic = detectTopic(question);
    const { answer, matchedCrop } = await generateAnswer(question, lang, crop ?? null, topic, supabase);

    // Save to chat history
    await supabase.from('ai_chat_history').insert({
      session_id: session_id || 'anonymous',
      question: question.trim(),
      answer,
      lang: lang || 'en',
      crop: matchedCrop,
    });

    return new Response(
      JSON.stringify({ answer, crop: matchedCrop, topic }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
