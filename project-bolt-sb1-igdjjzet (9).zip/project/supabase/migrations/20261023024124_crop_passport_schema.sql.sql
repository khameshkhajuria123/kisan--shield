/*
# Crop Passport & Traceability table

## Summary
Creates a `crop_passports` table so each harvest batch has a digital identity
with QR code, farm origin, harvest date, storage details, grading, and quality
history that buyers can verify.

## New Table: crop_passports
- id (uuid PK)
- session_id (text) — anonymous session identifier for the farmer who created it
- batch_id (text, unique) — human-readable batch code, auto-generated (e.g. KS-20261023-AB12)
- crop (text, not null)
- variety (text, nullable)
- farm_name (text, nullable)
- district (text, nullable)
- harvest_date (date, not null)
- quantity_kg (numeric, nullable)
- grade (text, nullable) — A, B, C
- storage_type (text, nullable) — cold storage, ambient, etc.
- storage_date (date, nullable)
- certifications (text, nullable) — organic, GAP, etc.
- quality_notes (text, nullable)
- qr_code (text, nullable) — URL-encodable string for QR generation
- status (text, default 'active') — active, sold, expired
- created_at (timestamptz)

## Security
- Single-tenant (no auth). RLS enabled, anon + authenticated full CRUD.
- All passports are publicly visible so buyers can scan QR and verify.
*/

CREATE TABLE IF NOT EXISTS crop_passports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  batch_id text UNIQUE NOT NULL DEFAULT 'KS-' || to_char(now(), 'YYYYMMDD') || '-' || upper(substr(encode(gen_random_bytes(3), 'hex'), 1, 4)),
  crop text NOT NULL,
  variety text,
  farm_name text,
  district text,
  harvest_date date NOT NULL DEFAULT CURRENT_DATE,
  quantity_kg numeric,
  grade text,
  storage_type text,
  storage_date date,
  certifications text,
  quality_notes text,
  qr_code text,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crop_passports ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON crop_passports TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_passports" ON crop_passports;
CREATE POLICY "anon_select_passports" ON crop_passports FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_passports" ON crop_passports;
CREATE POLICY "anon_insert_passports" ON crop_passports FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_passports" ON crop_passports;
CREATE POLICY "anon_update_passports" ON crop_passports FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_passports" ON crop_passports;
CREATE POLICY "anon_delete_passports" ON crop_passports FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_passport_session ON crop_passports(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_passport_batch ON crop_passports(batch_id);
CREATE INDEX IF NOT EXISTS idx_passport_crop ON crop_passports(crop, status);
