/*
# Kashmir KisanShield - Core Schema

## Overview
Creates the data layer for a multilingual farmer-support platform for J&K farmers.
Single-tenant app (no sign-in screen) so all policies allow anon + authenticated.
This is intentional public/shared data for a community app.

## Tables
1. `crop_calendar` - month-by-month farming operations for Kashmir crops (apple, saffron, rice, etc.)
2. `market_prices` - mandi prices by crop/grade/location/date
3. `govt_schemes` - central + J&K agricultural schemes with eligibility info
4. `weather_alerts` - cached weather risk alerts per location
5. `disease_library` - crop disease/pest reference with symptoms & treatment
6. `profit_records` - farm profit calculator saved calculations
7. `app_settings` - key-value app config (e.g. default language, contact info)

## Security
- RLS enabled on all tables.
- anon + authenticated CRUD (intentionally shared public data, no sign-in in app).
*/

-- Crop calendar: monthly operations per crop
CREATE TABLE IF NOT EXISTS crop_calendar (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  month int NOT NULL CHECK (month >= 1 AND month <= 12),
  operation text NOT NULL,
  detail text,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Market mandi prices
CREATE TABLE IF NOT EXISTS market_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  variety text,
  grade text,
  mandi text NOT NULL,
  district text,
  price_per_kg numeric NOT NULL,
  unit text DEFAULT 'kg',
  price_date date NOT NULL,
  source text,
  created_at timestamptz DEFAULT now()
);

-- Government schemes
CREATE TABLE IF NOT EXISTS govt_schemes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text,
  agency text,
  eligibility text,
  benefits text,
  documents text,
  deadline text,
  application_url text,
  created_at timestamptz DEFAULT now()
);

-- Cached weather alerts
CREATE TABLE IF NOT EXISTS weather_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location text NOT NULL,
  district text,
  alert_type text NOT NULL,
  severity text,
  description text,
  valid_from timestamptz,
  valid_to timestamptz,
  recommendation text,
  created_at timestamptz DEFAULT now()
);

-- Disease / pest reference library
CREATE TABLE IF NOT EXISTS disease_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  disease_name text NOT NULL,
  type text,
  symptoms text,
  treatment text,
  prevention text,
  severity text,
  created_at timestamptz DEFAULT now()
);

-- Saved profit calculations
CREATE TABLE IF NOT EXISTS profit_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  land_area numeric,
  area_unit text DEFAULT 'kanal',
  expected_yield_kg numeric,
  selling_price_per_kg numeric,
  total_cost numeric,
  created_at timestamptz DEFAULT now()
);

-- App key-value settings
CREATE TABLE IF NOT EXISTS app_settings (
  key text PRIMARY KEY,
  value text,
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all
ALTER TABLE crop_calendar ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE govt_schemes ENABLE ROW LEVEL SECURITY;
ALTER TABLE weather_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE disease_library ENABLE ROW LEVEL SECURITY;
ALTER TABLE profit_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- Crop calendar policies
DROP POLICY IF EXISTS "anon_select_crop_calendar" ON crop_calendar;
CREATE POLICY "anon_select_crop_calendar" ON crop_calendar FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_crop_calendar" ON crop_calendar;
CREATE POLICY "anon_insert_crop_calendar" ON crop_calendar FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_crop_calendar" ON crop_calendar;
CREATE POLICY "anon_update_crop_calendar" ON crop_calendar FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_crop_calendar" ON crop_calendar;
CREATE POLICY "anon_delete_crop_calendar" ON crop_calendar FOR DELETE TO anon, authenticated USING (true);

-- Market prices policies
DROP POLICY IF EXISTS "anon_select_market_prices" ON market_prices;
CREATE POLICY "anon_select_market_prices" ON market_prices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_market_prices" ON market_prices;
CREATE POLICY "anon_insert_market_prices" ON market_prices FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_market_prices" ON market_prices;
CREATE POLICY "anon_update_market_prices" ON market_prices FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_market_prices" ON market_prices;
CREATE POLICY "anon_delete_market_prices" ON market_prices FOR DELETE TO anon, authenticated USING (true);

-- Govt schemes policies
DROP POLICY IF EXISTS "anon_select_govt_schemes" ON govt_schemes;
CREATE POLICY "anon_select_govt_schemes" ON govt_schemes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_govt_schemes" ON govt_schemes;
CREATE POLICY "anon_insert_govt_schemes" ON govt_schemes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_govt_schemes" ON govt_schemes;
CREATE POLICY "anon_update_govt_schemes" ON govt_schemes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_govt_schemes" ON govt_schemes;
CREATE POLICY "anon_delete_govt_schemes" ON govt_schemes FOR DELETE TO anon, authenticated USING (true);

-- Weather alerts policies
DROP POLICY IF EXISTS "anon_select_weather_alerts" ON weather_alerts;
CREATE POLICY "anon_select_weather_alerts" ON weather_alerts FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_weather_alerts" ON weather_alerts;
CREATE POLICY "anon_insert_weather_alerts" ON weather_alerts FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_weather_alerts" ON weather_alerts;
CREATE POLICY "anon_update_weather_alerts" ON weather_alerts FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_weather_alerts" ON weather_alerts;
CREATE POLICY "anon_delete_weather_alerts" ON weather_alerts FOR DELETE TO anon, authenticated USING (true);

-- Disease library policies
DROP POLICY IF EXISTS "anon_select_disease_library" ON disease_library;
CREATE POLICY "anon_select_disease_library" ON disease_library FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_disease_library" ON disease_library;
CREATE POLICY "anon_insert_disease_library" ON disease_library FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_disease_library" ON disease_library;
CREATE POLICY "anon_update_disease_library" ON disease_library FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_disease_library" ON disease_library;
CREATE POLICY "anon_delete_disease_library" ON disease_library FOR DELETE TO anon, authenticated USING (true);

-- Profit records policies
DROP POLICY IF EXISTS "anon_select_profit_records" ON profit_records;
CREATE POLICY "anon_select_profit_records" ON profit_records FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_profit_records" ON profit_records;
CREATE POLICY "anon_insert_profit_records" ON profit_records FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_profit_records" ON profit_records;
CREATE POLICY "anon_update_profit_records" ON profit_records FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_profit_records" ON profit_records;
CREATE POLICY "anon_delete_profit_records" ON profit_records FOR DELETE TO anon, authenticated USING (true);

-- App settings policies
DROP POLICY IF EXISTS "anon_select_app_settings" ON app_settings;
CREATE POLICY "anon_select_app_settings" ON app_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_app_settings" ON app_settings;
CREATE POLICY "anon_insert_app_settings" ON app_settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_app_settings" ON app_settings;
CREATE POLICY "anon_update_app_settings" ON app_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_app_settings" ON app_settings;
CREATE POLICY "anon_delete_app_settings" ON app_settings FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_crop_calendar_crop ON crop_calendar(crop);
CREATE INDEX IF NOT EXISTS idx_crop_calendar_month ON crop_calendar(month);
CREATE INDEX IF NOT EXISTS idx_market_prices_crop ON market_prices(crop);
CREATE INDEX IF NOT EXISTS idx_market_prices_date ON market_prices(price_date);
CREATE INDEX IF NOT EXISTS idx_weather_alerts_location ON weather_alerts(location);
CREATE INDEX IF NOT EXISTS idx_disease_library_crop ON disease_library(crop);