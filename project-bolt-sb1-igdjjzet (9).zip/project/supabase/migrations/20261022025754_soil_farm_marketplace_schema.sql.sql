/*
# Soil Health, Farm Records, and Marketplace tables

## Summary
Adds three new tables for Phase 2/3 features:
1. `soil_reports` — farmer soil test reports with nutrient levels and irrigation planning
2. `farm_records` — season-by-season farm records (cost, production, sales)
3. `marketplace_listings` — crop listings from farmers visible to buyers

## New Tables

### soil_reports
- id (uuid PK)
- session_id (text) — anonymous session identifier
- crop (text) — crop the soil is for
- ph (numeric, nullable) — soil pH
- nitrogen (numeric, nullable) — N level kg/ha
- phosphorus (numeric, nullable) — P level kg/ha
- potassium (numeric, nullable) — K level kg/ha
- organic_carbon (numeric, nullable) — OC %
- soil_type (text, nullable) — clay, loam, sandy, etc.
- irrigation_advice (text, nullable) — auto-generated irrigation advice
- nutrient_advice (text, nullable) — auto-generated nutrient advice
- test_date (date)
- created_at (timestamptz)

### farm_records
- id (uuid PK)
- session_id (text)
- season (text) — e.g. "2025 Rabi", "2026 Kharif"
- crop (text)
- land_area (numeric, nullable)
- area_unit (text, default 'kanal')
- seed_cost (numeric, default 0)
- fertilizer_cost (numeric, default 0)
- labor_cost (numeric, default 0)
- other_cost (numeric, default 0)
- production_kg (numeric, nullable)
- sold_kg (numeric, nullable)
- sale_price_per_kg (numeric, nullable)
- notes (text, nullable)
- created_at (timestamptz)

### marketplace_listings
- id (uuid PK)
- session_id (text) — farmer session
- crop (text)
- variety (text, nullable)
- quantity_kg (numeric)
- grade (text, nullable) — A, B, C
- price_per_kg (numeric)
- district (text, nullable)
- contact_name (text, nullable)
- contact_phone (text, nullable)
- status (text, default 'active') — active, sold, withdrawn
- notes (text, nullable)
- created_at (timestamptz)

## Security
- All single-tenant (no auth). RLS with anon+authenticated full CRUD.
*/

CREATE TABLE IF NOT EXISTS soil_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  crop text NOT NULL,
  ph numeric,
  nitrogen numeric,
  phosphorus numeric,
  potassium numeric,
  organic_carbon numeric,
  soil_type text,
  irrigation_advice text,
  nutrient_advice text,
  test_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE soil_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_soil" ON soil_reports;
CREATE POLICY "anon_select_soil" ON soil_reports FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_soil" ON soil_reports;
CREATE POLICY "anon_insert_soil" ON soil_reports FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_soil" ON soil_reports;
CREATE POLICY "anon_update_soil" ON soil_reports FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_soil" ON soil_reports;
CREATE POLICY "anon_delete_soil" ON soil_reports FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS farm_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  season text NOT NULL,
  crop text NOT NULL,
  land_area numeric,
  area_unit text DEFAULT 'kanal',
  seed_cost numeric DEFAULT 0,
  fertilizer_cost numeric DEFAULT 0,
  labor_cost numeric DEFAULT 0,
  other_cost numeric DEFAULT 0,
  production_kg numeric,
  sold_kg numeric,
  sale_price_per_kg numeric,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE farm_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_farm" ON farm_records;
CREATE POLICY "anon_select_farm" ON farm_records FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_farm" ON farm_records;
CREATE POLICY "anon_insert_farm" ON farm_records FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_farm" ON farm_records;
CREATE POLICY "anon_update_farm" ON farm_records FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_farm" ON farm_records;
CREATE POLICY "anon_delete_farm" ON farm_records FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS marketplace_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  crop text NOT NULL,
  variety text,
  quantity_kg numeric NOT NULL,
  grade text,
  price_per_kg numeric NOT NULL,
  district text,
  contact_name text,
  contact_phone text,
  status text DEFAULT 'active',
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE marketplace_listings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_market" ON marketplace_listings;
CREATE POLICY "anon_select_market" ON marketplace_listings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_market" ON marketplace_listings;
CREATE POLICY "anon_insert_market" ON marketplace_listings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_market" ON marketplace_listings;
CREATE POLICY "anon_delete_market" ON marketplace_listings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_soil_session ON soil_reports(session_id, test_date DESC);
CREATE INDEX IF NOT EXISTS idx_farm_session ON farm_records(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_crop ON marketplace_listings(crop, status);
CREATE INDEX IF NOT EXISTS idx_market_district ON marketplace_listings(district, status);
