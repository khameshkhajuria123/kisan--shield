/*
# AI Assistant, Crop Risk, and Farmer Location tables

## Summary
Adds three new tables to support Phase 1 features:
1. `ai_chat_history` — stores farmer questions and AI assistant answers
2. `crop_risk_predictions` — crop risk predictions based on weather + disease data
3. `farmer_locations` — farmer GPS locations within Jammu & Kashmir

## New Tables

### ai_chat_history
- `id` (uuid PK)
- `session_id` (text) — anonymous session identifier (localStorage UUID)
- `question` (text) — farmer's question in their language
- `answer` (text) — AI assistant's answer
- `lang` (text) — language code of the question
- `crop` (text, nullable) — crop context if mentioned
- `created_at` (timestamptz)

### crop_risk_predictions
- `id` (uuid PK)
- `crop` (text) — crop name
- `district` (text, nullable) — J&K district
- `risk_type` (text) — frost, rain, hailstorm, disease, pest, etc.
- `risk_level` (text) — low, moderate, high, severe
- `growth_stage` (text, nullable) — flowering, fruiting, harvest, etc.
- `description` (text)
- `recommendation` (text)
- `valid_from` (timestamptz)
- `valid_to` (timestamptz, nullable)
- `created_at` (timestamptz)

### farmer_locations
- `id` (uuid PK)
- `session_id` (text) — anonymous session identifier
- `label` (text, nullable) — farm/area name
- `latitude` (double precision) — GPS lat
- `longitude` (double precision) — GPS lng
- `district` (text, nullable) — auto-detected district
- `created_at` (timestamptz)

## Security
- All tables are single-tenant (no auth). RLS enabled with anon+authenticated full CRUD.
- Data is intentionally public/shared for this no-auth farming app.
*/

CREATE TABLE IF NOT EXISTS ai_chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  question text NOT NULL,
  answer text NOT NULL,
  lang text NOT NULL DEFAULT 'en',
  crop text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_chat_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_ai_chat" ON ai_chat_history;
CREATE POLICY "anon_select_ai_chat" ON ai_chat_history FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_ai_chat" ON ai_chat_history;
CREATE POLICY "anon_insert_ai_chat" ON ai_chat_history FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_ai_chat" ON ai_chat_history;
CREATE POLICY "anon_delete_ai_chat" ON ai_chat_history FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS crop_risk_predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  district text,
  risk_type text NOT NULL,
  risk_level text NOT NULL DEFAULT 'moderate',
  growth_stage text,
  description text,
  recommendation text,
  valid_from timestamptz DEFAULT now(),
  valid_to timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crop_risk_predictions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_risk" ON crop_risk_predictions;
CREATE POLICY "anon_select_risk" ON crop_risk_predictions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_risk" ON crop_risk_predictions;
CREATE POLICY "anon_insert_risk" ON crop_risk_predictions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_risk" ON crop_risk_predictions;
CREATE POLICY "anon_delete_risk" ON crop_risk_predictions FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS farmer_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  label text,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  district text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE farmer_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_locations" ON farmer_locations;
CREATE POLICY "anon_select_locations" ON farmer_locations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_locations" ON farmer_locations;
CREATE POLICY "anon_insert_locations" ON farmer_locations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_locations" ON farmer_locations;
CREATE POLICY "anon_delete_locations" ON farmer_locations FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_ai_chat_session ON ai_chat_history(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_risk_crop ON crop_risk_predictions(crop);
CREATE INDEX IF NOT EXISTS idx_locations_session ON farmer_locations(session_id);

-- Seed initial crop risk data for J&K
INSERT INTO crop_risk_predictions (crop, district, risk_type, risk_level, growth_stage, description, recommendation, valid_from, valid_to)
VALUES
  ('Apple', 'Baramulla', 'Frost', 'high', 'Flowering', 'Night temperatures dropping below 2°C during April flowering stage. Frost can damage blossoms and reduce fruit set significantly.', 'Use overhead sprinklers or smudge pots during frost nights. Cover young trees with frost nets. Monitor temperature closely.', now(), now() + interval '7 days'),
  ('Apple', 'Shopian', 'Hailstorm', 'moderate', 'Fruiting', 'Hailstorm risk during June-July fruiting stage. Hail can bruise and damage developing fruits.', 'Install anti-hail nets over orchards. Stay updated with weather alerts. Inspect trees after hail events.', now(), now() + interval '5 days'),
  ('Saffron', 'Pulwama', 'Disease', 'moderate', 'Flowering', 'Corm rot risk increases with excessive soil moisture during October-November flowering. Fungal infections common in waterlogged fields.', 'Ensure proper drainage. Avoid over-irrigation. Apply recommended fungicide if symptoms appear.', now(), now() + interval '14 days'),
  ('Rice', 'Kupwara', 'Flood', 'high', 'Vegetative', 'Heavy rainfall forecast may cause waterlogging in low-lying paddy fields during July-August vegetative stage.', 'Ensure field bunds are intact. Maintain proper drainage channels. Monitor water levels daily.', now(), now() + interval '3 days'),
  ('Walnut', 'Kupwara', 'Pest', 'moderate', 'Fruiting', 'Codling moth activity expected during May-June. Larvae bore into developing nuts causing quality loss.', 'Install pheromone traps. Spray recommended insecticide at petal fall. Remove fallen nuts promptly.', now(), now() + interval '10 days'),
  ('Maize', 'Anantnag', 'Drought', 'moderate', 'Vegetative', 'Below-normal rainfall expected during July. Maize at vegetative stage is sensitive to moisture stress.', 'Apply mulch to conserve soil moisture. irrigate at critical growth stages. Use drought-tolerant varieties next season.', now(), now() + interval '14 days'),
  ('Apple', 'Srinagar', 'Disease', 'high', 'Fruiting', 'Apple scab risk high during humid weather in May-June. Fungal spores spread rapidly with rain splash.', 'Apply fungicide sprays at 7-10 day intervals during wet weather. Prune for better air circulation. Remove fallen leaves.', now(), now() + interval '10 days'),
  ('Saffron', 'Srinagar', 'Frost', 'moderate', 'Vegetative', 'Early frost may damage saffron corms in November if soil temperature drops rapidly.', 'Apply straw mulch over corm beds. Avoid late irrigation. Monitor soil temperature.', now(), now() + interval '14 days')
ON CONFLICT DO NOTHING;
